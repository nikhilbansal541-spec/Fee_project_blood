import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { DonationCamp } from '../../types';
import { BloodCompatibilityWidget } from '../BloodCompatibilityWidget';
import { sfx } from '../../utils/audio';

interface HomeDashboardProps {
  onNavigate: (view: string) => void;
  onRequestBlood: () => void;
  onTrackRequest: () => void;
  onRegisterDonor: () => void;
  onSelectCamp: (camp: DonationCamp) => void;
  camps: DonationCamp[];
  donorsCount: number;
}

export const HomeDashboard: React.FC<HomeDashboardProps> = ({
  onNavigate,
  onRequestBlood,
  onTrackRequest,
  onRegisterDonor,
  onSelectCamp,
  camps,
  donorsCount,
}) => {
  // Animated counters
  const [counts, setCounts] = useState({
    donors: 0,
    donations: 0,
    lives: 0,
    camps: 0,
  });

  const [activePinIndex, setActivePinIndex] = useState<number | null>(null);

  useEffect(() => {
    const targets = {
      donors: 8920 + donorsCount,
      donations: 12450,
      lives: 300,
      camps: 320,
    };

    let start = 0;
    const duration = 1200;
    const intervalTime = 25;
    const steps = duration / intervalTime;

    const timer = setInterval(() => {
      start++;
      const progress = Math.min(start / steps, 1);
      setCounts({
        donors: Math.floor(targets.donors * progress),
        donations: Math.floor(targets.donations * progress),
        lives: Math.floor(targets.lives * progress),
        camps: Math.floor(targets.camps * progress),
      });

      if (progress >= 1) {
        clearInterval(timer);
      }
    }, intervalTime);

    return () => clearInterval(timer);
  }, [donorsCount]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: 'easeOut' }}
      className="w-full flex flex-col gap-8 pb-10"
    >
      {/* ================= HERO SECTION WITH AMBIENT GLOW ================= */}
      <section className="relative flex flex-col lg:flex-row items-center justify-between gap-8 min-h-[480px] py-4">
        {/* Ambient background glows */}
        <div className="absolute -top-10 -left-10 w-96 h-96 bg-red-600/10 rounded-full blur-[120px] pointer-events-none -z-10" />
        <div className="absolute top-1/2 right-10 w-80 h-80 bg-red-600/15 rounded-full blur-[140px] pointer-events-none -z-10" />

        {/* Left Hero Text */}
        <motion.div
          initial={{ opacity: 0, x: -25 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="flex-1 flex flex-col justify-center"
        >
          {/* Badge */}
          <div className="inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-red-950/50 border border-red-800/60 text-red-300 text-xs font-bold tracking-wider uppercase mb-4 w-fit shadow-lg shadow-red-950/40">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-600"></span>
            </span>
            <span>24/7 National Emergency Blood Grid</span>
          </div>

          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-black tracking-tight leading-[1.04] mb-4 text-white">
            SAVE BLOOD.<br />
            <span className="shimmer-text">SAVE LIVES.</span>
          </h1>

          <p className="text-gray-300 text-base sm:text-lg mb-8 max-w-lg leading-relaxed font-normal">
            Every second counts. Connect instantly with verified voluntary donors across your city or broadcast an emergency blood request with instant dispatcher tracking.
          </p>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-4">
            <motion.button
              whileHover={{ scale: 1.04, y: -2 }}
              whileTap={{ scale: 0.98 }}
              onClick={onRegisterDonor}
              className="px-7 py-3.5 rounded-xl bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white font-bold text-sm tracking-wide shadow-xl shadow-red-950/80 hover:shadow-red-800/90 transition-all flex items-center gap-2.5 cursor-pointer border border-red-500/50"
            >
              <i className="fa-solid fa-heart-pulse animate-heartbeat text-red-200"></i>
              Donate Blood
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.04, y: -2 }}
              whileTap={{ scale: 0.98 }}
              onClick={onRequestBlood}
              className="px-7 py-3.5 rounded-xl bg-[#10141d]/80 hover:bg-red-950/40 text-white font-bold text-sm tracking-wide border border-white/10 hover:border-red-500/60 shadow-lg transition-all flex items-center gap-2.5 cursor-pointer backdrop-blur-md"
            >
              <i className="fa-solid fa-magnifying-glass text-red-400"></i>
              Find Blood
            </motion.button>
          </div>
        </motion.div>

        {/* Story Card with 3D Border Glow */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="w-full lg:w-[490px] glass-panel rounded-2xl border border-white/10 hover:border-red-500/40 shadow-2xl shadow-red-950/30 flex flex-col sm:flex-row overflow-hidden shrink-0 group transition-all duration-300 hover:shadow-red-900/20"
        >
          {/* Timeline */}
          <div className="sm:w-[48%] p-5 flex flex-col justify-between border-b sm:border-b-0 sm:border-r border-white/5 space-y-4 bg-[#0a0d14]/70">
            <div className="relative pl-4 border-l-2 border-red-600/50">
              <span className="absolute -left-[5px] top-1.5 w-2 h-2 bg-red-600 rounded-full shadow-[0_0_8px_#e60000]"></span>
              <span className="text-xs font-black text-red-500 mr-1.5">01</span>
              <h4 className="text-xs font-bold text-white inline">One Donor</h4>
              <p className="text-[11px] text-[#8b95a5] mt-0.5">A decision to help.</p>
            </div>

            <div className="relative pl-4 border-l-2 border-red-600/50">
              <span className="absolute -left-[5px] top-1.5 w-2 h-2 bg-red-600 rounded-full shadow-[0_0_8px_#e60000]"></span>
              <span className="text-xs font-black text-red-500 mr-1.5">02</span>
              <h4 className="text-xs font-bold text-white inline">One Donation</h4>
              <p className="text-[11px] text-[#8b95a5] mt-0.5">A drop of hope.</p>
            </div>

            <div className="relative pl-4 border-l-2 border-red-600/50">
              <span className="absolute -left-[5px] top-1.5 w-2 h-2 bg-red-600 rounded-full shadow-[0_0_8px_#e60000]"></span>
              <span className="text-xs font-black text-red-500 mr-1.5">03</span>
              <h4 className="text-xs font-bold text-white inline">One Life</h4>
              <p className="text-[11px] text-[#8b95a5] mt-0.5">A new chance to live.</p>
            </div>

            <div className="relative pl-4 border-l-2 border-red-600/50">
              <span className="absolute -left-[5px] top-1.5 w-2 h-2 bg-red-600 rounded-full shadow-[0_0_8px_#e60000]"></span>
              <span className="text-xs font-black text-red-500 mr-1.5">04</span>
              <h4 className="text-xs font-bold text-white inline">Be The Reason</h4>
              <p className="text-[11px] text-[#8b95a5] mt-0.5">Someone is waiting for you.</p>
            </div>
          </div>

          {/* Image & Overlay */}
          <div className="sm:w-[52%] relative min-h-[230px] overflow-hidden">
            <img
              src="https://images.unsplash.com/photo-1536856136534-bb679c52a9aa?q=80&w=600&auto=format&fit=crop"
              alt="Blood Donation"
              className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/60 to-transparent p-5 flex flex-col justify-end items-center text-center">
              <h2 className="text-lg font-black text-white mb-2 leading-tight">
                Small Act.<br />Big Impact.
              </h2>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={onRegisterDonor}
                className="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white font-bold text-xs tracking-wider uppercase shadow-lg shadow-red-950 transition-all cursor-pointer"
              >
                Donate Now
              </motion.button>
            </div>
          </div>
        </motion.div>

        {/* Pulsing 3D-Look SVG Blood Droplet */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.7, delay: 0.3 }}
          className="hidden xl:flex items-center justify-center shrink-0 w-44"
        >
          <div className="w-36 h-48 animate-float">
            <svg
              viewBox="0 0 200 250"
              xmlns="http://www.w3.org/2000/svg"
              className="w-full h-full filter drop-shadow-[0_0_35px_rgba(230,0,0,0.65)]"
            >
              <defs>
                <radialGradient id="dropGradReact" cx="30%" cy="30%" r="70%">
                  <stop offset="0%" stopColor="#ff4747" />
                  <stop offset="40%" stopColor="#cc0000" />
                  <stop offset="100%" stopColor="#280000" />
                </radialGradient>
              </defs>
              <path
                d="M100 10 C100 10,20 120,20 180 C20 224.18,55.82 260,100 260 C144.18 260,180 224.18,180 180 C180 120,100 10,100 10 Z"
                fill="url(#dropGradReact)"
              />
              <polygon
                points="100,40 60,140 100,160 140,140"
                fill="none"
                stroke="rgba(255,255,255,0.25)"
                strokeWidth="0.8"
              />
              <polygon
                points="60,140 35,180 100,240 165,180 140,140"
                fill="none"
                stroke="rgba(255,255,255,0.25)"
                strokeWidth="0.8"
              />
              <path
                d="M100 40 L60 140 L35 180 L100 240 L165 180 L140 140 Z"
                fill="none"
                stroke="rgba(255,180,180,0.85)"
                strokeDasharray="6 4"
                strokeWidth="1.3"
              />
              {/* Pulsing Nodes */}
              <circle cx="100" cy="40" r="3.5" fill="#fff" className="animate-node-pulse" />
              <circle cx="60" cy="140" r="3.5" fill="#fff" className="animate-node-pulse" />
              <circle cx="140" cy="140" r="3.5" fill="#fff" className="animate-node-pulse" />
              <circle cx="100" cy="100" r="2.5" fill="#fff" className="animate-node-pulse" />
              <circle cx="35" cy="180" r="3.5" fill="#fff" className="animate-node-pulse" />
              <circle cx="165" cy="180" r="3.5" fill="#fff" className="animate-node-pulse" />
              <circle cx="100" cy="240" r="3.5" fill="#fff" className="animate-node-pulse" />
            </svg>
          </div>
        </motion.div>
      </section>

      {/* ================= INTERACTIVE RADAR COMPATIBILITY WIDGET ================= */}
      <BloodCompatibilityWidget />

      {/* ================= DASHBOARD GRIDS ================= */}
      <section className="space-y-4">
        {/* ROW 1: 4 FEATURE CARDS (HIGH LEVEL MICRO-INTERACTIONS) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Card 1: Request Blood */}
          <motion.button
            whileHover={{ y: -4, scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={onRequestBlood}
            className="group relative p-6 glass-panel rounded-2xl text-center flex flex-col items-center justify-center transition-all duration-300 hover:border-red-500/70 hover:shadow-2xl hover:shadow-red-950/50 cursor-pointer overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-b from-red-600/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            <div className="relative w-14 h-14 rounded-2xl bg-red-600/15 group-hover:bg-red-600 text-2xl text-red-500 group-hover:text-white flex items-center justify-center mb-3 transition-all duration-300 group-hover:rotate-6 shadow-lg shadow-red-950/40">
              <i className="fa-solid fa-file-invoice"></i>
            </div>
            <h3 className="relative text-base font-bold text-white group-hover:text-red-400 transition-colors mb-1">
              Request Blood
            </h3>
            <p className="relative text-xs text-[#8b95a5]">Get help in emergency</p>
            <span className="relative mt-3 text-[11px] font-bold text-red-500 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-y-1 group-hover:translate-y-0">
              Create Request <i className="fa-solid fa-arrow-right text-[9px]"></i>
            </span>
          </motion.button>

          {/* Card 2: Find Donors */}
          <motion.button
            whileHover={{ y: -4, scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => onNavigate('donors')}
            className="group relative p-6 glass-panel rounded-2xl text-center flex flex-col items-center justify-center transition-all duration-300 hover:border-red-500/70 hover:shadow-2xl hover:shadow-red-950/50 cursor-pointer overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-b from-red-600/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            <div className="relative w-14 h-14 rounded-2xl bg-red-600/15 group-hover:bg-red-600 text-2xl text-red-500 group-hover:text-white flex items-center justify-center mb-3 transition-all duration-300 group-hover:rotate-6 shadow-lg shadow-red-950/40">
              <i className="fa-regular fa-user"></i>
            </div>
            <h3 className="relative text-base font-bold text-white group-hover:text-red-400 transition-colors mb-1">
              Find Donors
            </h3>
            <p className="relative text-xs text-[#8b95a5]">Connect with donors</p>
            <span className="relative mt-3 text-[11px] font-bold text-red-500 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-y-1 group-hover:translate-y-0">
              Browse Directory <i className="fa-solid fa-arrow-right text-[9px]"></i>
            </span>
          </motion.button>

          {/* Card 3: Track Request */}
          <motion.button
            whileHover={{ y: -4, scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={onTrackRequest}
            className="group relative p-6 glass-panel rounded-2xl text-center flex flex-col items-center justify-center transition-all duration-300 hover:border-red-500/70 hover:shadow-2xl hover:shadow-red-950/50 cursor-pointer overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-b from-red-600/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            <div className="relative w-14 h-14 rounded-2xl bg-red-600/15 group-hover:bg-red-600 text-2xl text-red-500 group-hover:text-white flex items-center justify-center mb-3 transition-all duration-300 group-hover:rotate-6 shadow-lg shadow-red-950/40">
              <i className="fa-solid fa-map-location-dot"></i>
            </div>
            <h3 className="relative text-base font-bold text-white group-hover:text-red-400 transition-colors mb-1">
              Track Request
            </h3>
            <p className="relative text-xs text-[#8b95a5]">Track your request</p>
            <span className="relative mt-3 text-[11px] font-bold text-red-500 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-y-1 group-hover:translate-y-0">
              Live Status <i className="fa-solid fa-arrow-right text-[9px]"></i>
            </span>
          </motion.button>

          {/* Card 4: Donation Camps */}
          <motion.button
            whileHover={{ y: -4, scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => onNavigate('camps')}
            className="group relative p-6 glass-panel rounded-2xl text-center flex flex-col items-center justify-center transition-all duration-300 hover:border-red-500/70 hover:shadow-2xl hover:shadow-red-950/50 cursor-pointer overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-b from-red-600/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            <div className="relative w-14 h-14 rounded-2xl bg-red-600/15 group-hover:bg-red-600 text-2xl text-red-500 group-hover:text-white flex items-center justify-center mb-3 transition-all duration-300 group-hover:rotate-6 shadow-lg shadow-red-950/40">
              <i className="fa-solid fa-tent"></i>
            </div>
            <h3 className="relative text-base font-bold text-white group-hover:text-red-400 transition-colors mb-1">
              Donation Camps
            </h3>
            <p className="relative text-xs text-[#8b95a5]">Join donation drives</p>
            <span className="relative mt-3 text-[11px] font-bold text-red-500 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-y-1 group-hover:translate-y-0">
              View Schedules <i className="fa-solid fa-arrow-right text-[9px]"></i>
            </span>
          </motion.button>
        </div>

        {/* ROW 2: STAT CARDS + RADAR MAP CARD */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-4">
          {/* Stat 1 */}
          <motion.div
            whileHover={{ scale: 1.03, y: -2 }}
            onClick={() => onNavigate('donors')}
            className="p-4 glass-panel rounded-xl text-center flex flex-col justify-center items-center transition-all cursor-pointer group"
          >
            <p className="text-xs text-[#8b95a5] font-semibold mb-1 group-hover:text-gray-300">Donors</p>
            <div className="text-2xl font-black text-white group-hover:text-red-400">
              {counts.donors.toLocaleString()}+
            </div>
          </motion.div>

          {/* Stat 2 */}
          <motion.div
            whileHover={{ scale: 1.03, y: -2 }}
            onClick={() => onNavigate('services')}
            className="p-4 glass-panel rounded-xl text-center flex flex-col justify-center items-center transition-all cursor-pointer group"
          >
            <p className="text-xs text-[#8b95a5] font-semibold mb-1 group-hover:text-gray-300">Donations</p>
            <div className="text-2xl font-black text-white group-hover:text-red-400">
              {counts.donations.toLocaleString()}+
            </div>
          </motion.div>

          {/* Stat 3 */}
          <motion.div
            whileHover={{ scale: 1.03, y: -2 }}
            onClick={() => onNavigate('about')}
            className="p-4 glass-panel rounded-xl text-center flex flex-col justify-center items-center transition-all cursor-pointer group"
          >
            <p className="text-xs text-[#8b95a5] font-semibold mb-1 group-hover:text-gray-300">Lives Saved</p>
            <div className="text-2xl font-black text-white group-hover:text-red-400">
              {counts.lives.toLocaleString()}+
            </div>
          </motion.div>

          {/* Stat 4 */}
          <motion.div
            whileHover={{ scale: 1.03, y: -2 }}
            onClick={() => onNavigate('camps')}
            className="p-4 glass-panel rounded-xl text-center flex flex-col justify-center items-center transition-all cursor-pointer group"
          >
            <p className="text-xs text-[#8b95a5] font-semibold mb-1 group-hover:text-gray-300">Camps</p>
            <div className="text-2xl font-black text-white group-hover:text-red-400">
              {counts.camps.toLocaleString()}+
            </div>
          </motion.div>

          {/* RADAR MAP CARD WITH SCANNER SWEEP ANIMATION */}
          <div className="col-span-2 relative min-h-[130px] bg-gradient-to-r from-[#141924] to-[#0a0d14] border border-red-500/30 hover:border-red-500 rounded-xl p-3.5 overflow-hidden flex flex-col justify-between transition-all group shadow-xl">
            {/* Dots background pattern */}
            <div
              className="absolute inset-0 opacity-25 pointer-events-none"
              style={{
                backgroundImage: 'radial-gradient(#667 1px, transparent 1px)',
                backgroundSize: '12px 12px',
              }}
            />

            {/* Radar scanner sweep line */}
            <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-30">
              <div
                className="w-full h-full animate-radar-sweep origin-center"
                style={{
                  background: 'conic-gradient(from 0deg, transparent 0deg, rgba(230,0,0,0.3) 60deg, transparent 65deg)',
                }}
              />
            </div>

            <div className="relative z-10 flex items-center justify-between">
              <h4 className="text-xs font-black tracking-wider text-white uppercase flex items-center gap-1.5">
                <i className="fa-solid fa-satellite-dish text-red-500 animate-pulse"></i>
                FIND A CAMP NEAR YOU
              </h4>
              <button
                onClick={() => onNavigate('camps')}
                className="text-[10px] text-red-400 hover:text-white hover:underline font-bold"
              >
                View All &rarr;
              </button>
            </div>

            {/* Clickable Map Pins with expanding beacons */}
            <div className="relative h-16 w-full mt-1">
              {camps.map((camp, idx) => (
                <div
                  key={camp.id}
                  style={{ top: camp.pinPosition.top, left: camp.pinPosition.left }}
                  className="absolute cursor-pointer -translate-x-1/2 -translate-y-1/2 group/pin z-20"
                  onClick={() => onSelectCamp(camp)}
                  onMouseEnter={() => setActivePinIndex(idx)}
                  onMouseLeave={() => setActivePinIndex(null)}
                >
                  {/* Expanding translucent pulse beacon */}
                  <span className="absolute -inset-1 rounded-full bg-red-500/40 animate-beacon pointer-events-none"></span>

                  {/* Core glowing dot */}
                  <div className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse-pin shadow-[0_0_12px_#ff4747]"></div>
                  <i className="fa-solid fa-location-dot absolute -top-3.5 -left-1 text-red-400 text-xs"></i>

                  {/* Tooltip / Label */}
                  <div
                    className={`absolute left-3 -top-2 whitespace-nowrap px-2.5 py-0.5 rounded text-[10px] font-bold border transition-all ${
                      activePinIndex === idx
                        ? 'scale-110 bg-red-600 text-white border-red-400 shadow-[0_0_15px_rgba(230,0,0,0.8)] z-30'
                        : 'bg-black/90 text-gray-200 border-red-500/40 opacity-90'
                    }`}
                  >
                    {camp.badgeText}
                  </div>
                </div>
              ))}
            </div>

            <p className="relative z-10 text-[10px] text-gray-400 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              Tap any location beacon to book appointment slot.
            </p>
          </div>
        </div>
      </section>
    </motion.div>
  );
};
