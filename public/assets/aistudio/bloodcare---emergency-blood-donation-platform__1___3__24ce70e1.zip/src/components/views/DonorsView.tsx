import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Donor } from '../../types';

interface DonorsViewProps {
  donors: Donor[];
  onContactDonor: (donor: Donor) => void;
  onRegisterDonor: () => void;
}

export const DonorsView: React.FC<DonorsViewProps> = ({
  donors,
  onContactDonor,
  onRegisterDonor,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBlood, setSelectedBlood] = useState<string>('all');
  const [onlyAvailable, setOnlyAvailable] = useState(false);

  const filteredDonors = donors.filter((donor) => {
    const matchesSearch =
      donor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      donor.city.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesBlood = selectedBlood === 'all' || donor.bloodGroup === selectedBlood;
    const matchesAvail = !onlyAvailable || donor.available;

    return matchesSearch && matchesBlood && matchesAvail;
  });

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="w-full space-y-8 pb-16"
    >
      {/* ================= HEADING ================= */}
      <section className="text-center pt-2">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-950/40 border border-red-800/40 text-red-400 text-xs font-bold tracking-wider uppercase mb-3">
          <i className="fa-solid fa-users-viewfinder"></i> Verified Community Network
        </div>
        <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight mb-3">
          OUR <span className="shimmer-text">DONORS.</span>
        </h1>
        <p className="text-sm sm:text-base text-[#8b95a5] max-w-xl mx-auto">
          Meet the verified heroes in your city ready to step forward when medical emergencies arise.
        </p>
      </section>

      {/* ================= SEARCH & ACTIONS ================= */}
      <section className="max-w-4xl mx-auto glass-panel rounded-2xl p-4 sm:p-5 shadow-2xl border border-white/10 hover:border-red-500/40 transition-all">
        <div className="flex flex-col sm:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <i className="fa-solid fa-magnifying-glass absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
            <input
              type="text"
              placeholder="Search donor by name or city (e.g. Rahul, Chandigarh, Mohali)..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full h-12 pl-10 pr-4 bg-[#06080c] border border-[#1e2533] focus:border-red-500 rounded-xl text-sm text-white outline-none transition-all focus:ring-1 focus:ring-red-500"
            />
          </div>

          <div className="w-full sm:w-48">
            <select
              value={selectedBlood}
              onChange={(e) => setSelectedBlood(e.target.value)}
              className="w-full h-12 px-3 bg-[#06080c] border border-[#1e2533] focus:border-red-500 rounded-xl text-sm text-white outline-none cursor-pointer"
            >
              <option value="all">All Blood Groups</option>
              <option value="A+">A+</option>
              <option value="A-">A-</option>
              <option value="B+">B+</option>
              <option value="B-">B-</option>
              <option value="O+">O+</option>
              <option value="O-">O-</option>
              <option value="AB+">AB+</option>
              <option value="AB-">AB-</option>
            </select>
          </div>

          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            onClick={onRegisterDonor}
            className="w-full sm:w-auto h-12 px-5 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white font-bold text-xs tracking-wider uppercase rounded-xl shadow-lg shadow-red-950 transition-all flex items-center justify-center gap-2 shrink-0 cursor-pointer border border-red-500/50"
          >
            <i className="fa-solid fa-plus"></i>
            Join as Donor
          </motion.button>
        </div>

        {/* Filter Badges */}
        <div className="flex flex-wrap items-center justify-between gap-3 mt-4 pt-3 border-t border-white/5 text-xs">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[#8b95a5]">Quick Filter:</span>
            {(['all', 'O+', 'O-', 'A+', 'B+', 'AB+'] as const).map((bg) => (
              <button
                key={bg}
                onClick={() => setSelectedBlood(bg)}
                className={`px-3 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                  selectedBlood === bg
                    ? 'bg-red-600 text-white shadow-md shadow-red-950'
                    : 'bg-[#06080c] text-gray-400 hover:text-white border border-[#1e2533]'
                }`}
              >
                {bg === 'all' ? 'All Groups' : bg}
              </button>
            ))}
          </div>

          <label className="flex items-center gap-2 text-[#8b95a5] hover:text-white cursor-pointer select-none">
            <input
              type="checkbox"
              checked={onlyAvailable}
              onChange={(e) => setOnlyAvailable(e.target.checked)}
              className="w-3.5 h-3.5 accent-red-600 rounded"
            />
            Available Donors Only
          </label>
        </div>
      </section>

      {/* ================= DONOR CARDS GRID WITH STAGGER ================= */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {filteredDonors.map((donor, idx) => (
          <motion.div
            key={donor.id}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, delay: idx * 0.05 }}
            whileHover={{ y: -6, scale: 1.02 }}
            className="glass-panel rounded-2xl p-6 text-center transition-all duration-300 hover:border-red-500/60 hover:shadow-2xl hover:shadow-red-950/50 flex flex-col justify-between group relative overflow-hidden"
          >
            {/* Top ambient highlight line */}
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-red-600/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

            <div>
              {/* Blood droplet icon with glowing aura */}
              <div className="relative w-16 h-16 mx-auto mb-4 rounded-full bg-red-600/15 group-hover:bg-red-600/25 flex items-center justify-center text-3xl transition-transform group-hover:scale-110 shadow-lg shadow-red-950/30">
                🩸
                {donor.available && (
                  <span className="absolute bottom-0 right-0 w-4 h-4 bg-emerald-500 rounded-full border-2 border-[#12161f] animate-pulse" />
                )}
              </div>

              <div className="flex items-center justify-center gap-1.5 mb-1">
                <h2 className="text-lg font-bold text-white group-hover:text-red-400 transition-colors">
                  {donor.name}
                </h2>
                {donor.verified && (
                  <i className="fa-solid fa-circle-check text-emerald-400 text-xs" title="Verified Donor"></i>
                )}
              </div>

              {/* Blood group badge */}
              <div className="inline-block px-4 py-1 rounded-full bg-gradient-to-r from-red-600/20 to-red-900/30 text-red-400 border border-red-500/40 font-black text-sm mb-3">
                {donor.bloodGroup}
              </div>

              <p className="text-xs text-[#8b95a5] mb-2 flex items-center justify-center gap-1.5">
                <span>📍</span> {donor.city}
              </p>

              <div className="flex items-center justify-center gap-2 mb-4">
                <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-[#0b0e14] text-gray-300 border border-white/5">
                  {donor.donationsCount} Donations
                </span>
                <span
                  className={`text-[10px] font-semibold px-2 py-0.5 rounded ${
                    donor.available
                      ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800/60'
                      : 'bg-gray-900 text-gray-400'
                  }`}
                >
                  {donor.available ? 'Ready Now' : 'Resting'}
                </span>
              </div>
            </div>

            {/* Contact Donor Button */}
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={() => onContactDonor(donor)}
              className="w-full py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs tracking-wider uppercase transition-all shadow-md shadow-red-950 hover:shadow-red-800 flex items-center justify-center gap-2 cursor-pointer border border-red-500/50"
            >
              <i className="fa-solid fa-paper-plane text-[11px]"></i>
              Contact Donor
            </motion.button>
          </motion.div>
        ))}
      </section>

      {filteredDonors.length === 0 && (
        <div className="text-center py-16 glass-panel rounded-2xl p-8 max-w-md mx-auto space-y-4">
          <div className="text-4xl text-gray-500 animate-bounce">🔍</div>
          <h3 className="text-lg font-bold text-white">No Donors Match Your Filter</h3>
          <p className="text-xs text-[#8b95a5]">
            No verified donors match your search. Try resetting filters or register yourself as a life-saving donor in this area.
          </p>
          <button
            onClick={() => {
              setSearchTerm('');
              setSelectedBlood('all');
              setOnlyAvailable(false);
            }}
            className="px-4 py-2 bg-[#181d29] hover:bg-[#202737] text-white rounded-lg text-xs font-semibold border border-white/10 cursor-pointer"
          >
            Reset All Filters
          </button>
        </div>
      )}
    </motion.div>
  );
};
