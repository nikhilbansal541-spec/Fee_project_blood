import React, { useState } from 'react';
import { motion } from 'motion/react';
import { DonationCamp } from '../../types';

interface CampsViewProps {
  camps: DonationCamp[];
  onBookCamp: (camp: DonationCamp) => void;
}

export const CampsView: React.FC<CampsViewProps> = ({ camps, onBookCamp }) => {
  const [filterCity, setFilterCity] = useState('all');

  const filteredCamps = camps.filter(
    (c) => filterCity === 'all' || c.city.toLowerCase() === filterCity.toLowerCase()
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="w-full space-y-8 pb-16"
    >
      {/* ================= HEADING ================= */}
      <section className="text-center pt-2 max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-red-950/40 border border-red-800/40 text-red-400 text-xs font-bold tracking-wider uppercase mb-3">
          <i className="fa-solid fa-tent"></i> Community Blood Drives
        </div>
        <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight mb-3">
          DONATION <span className="shimmer-text">CAMPS.</span>
        </h1>
        <p className="text-sm sm:text-base text-[#8b95a5]">
          Find nearby voluntary donation camps organized by hospitals and Red Cross. Book your preferred time slot to avoid waiting lines.
        </p>
      </section>

      {/* Filter bar */}
      <div className="max-w-xl mx-auto flex items-center justify-center gap-3">
        <span className="text-xs text-[#8b95a5]">Location Filter:</span>
        {(['all', 'chandigarh', 'mohali'] as const).map((city) => (
          <button
            key={city}
            onClick={() => setFilterCity(city)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              filterCity === city
                ? 'bg-red-600 text-white shadow-lg shadow-red-950/60 scale-105'
                : 'glass-panel text-gray-400 hover:text-white'
            }`}
          >
            {city === 'all' ? 'All Locations' : city.charAt(0).toUpperCase() + city.slice(1)}
          </button>
        ))}
      </div>

      {/* Camps Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCamps.map((camp, idx) => {
          const percentBooked = Math.round((camp.bookedSlots / camp.totalSlots) * 100);

          return (
            <motion.div
              key={camp.id}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: idx * 0.1 }}
              whileHover={{ y: -6, scale: 1.02 }}
              className="glass-panel rounded-2xl p-6 transition-all duration-300 hover:border-red-500/70 hover:shadow-2xl hover:shadow-red-950/40 flex flex-col justify-between group relative overflow-hidden"
            >
              <div className="space-y-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="w-12 h-12 rounded-2xl bg-red-600/15 text-red-500 group-hover:bg-red-600 group-hover:text-white flex items-center justify-center text-xl shrink-0 transition-colors duration-300 shadow-md">
                    <i className="fa-solid fa-tent"></i>
                  </div>
                  <span className="px-3 py-1 rounded-full text-[10px] font-black tracking-wider bg-red-950/70 text-red-300 border border-red-700/60 shadow-sm animate-pulse">
                    {camp.daysLeft} Days Left
                  </span>
                </div>

                <div>
                  <h3 className="text-lg font-bold text-white group-hover:text-red-400 transition-colors mb-1">
                    {camp.title}
                  </h3>
                  <p className="text-xs text-[#8b95a5] flex items-start gap-1.5">
                    <span className="text-red-500">📍</span> {camp.address}
                  </p>
                </div>

                <div className="p-3.5 bg-[#080b11] rounded-xl border border-white/5 text-xs space-y-2">
                  <div className="flex items-center justify-between text-gray-200">
                    <span className="flex items-center gap-1.5 font-semibold">
                      <i className="fa-solid fa-calendar-day text-red-500"></i> {camp.date}
                    </span>
                    <span className="text-[11px] text-gray-400 font-mono">{camp.time}</span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-[#8b95a5] pt-1 border-t border-white/5">
                    <span>Organized by:</span>
                    <span className="text-gray-200 font-semibold">{camp.organizer}</span>
                  </div>
                </div>

                {/* Animated Slots Bar */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-[#8b95a5]">Slots Reserved</span>
                    <span className="font-bold text-white">
                      {camp.bookedSlots} / {camp.totalSlots} ({percentBooked}%)
                    </span>
                  </div>
                  <div className="w-full h-2.5 bg-[#06080c] rounded-full overflow-hidden border border-white/5">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${percentBooked}%` }}
                      transition={{ duration: 1, delay: 0.2 }}
                      className="h-full bg-gradient-to-r from-red-600 via-red-500 to-rose-400 rounded-full shadow-[0_0_10px_rgba(230,0,0,0.5)]"
                    />
                  </div>
                </div>

                {/* Perks */}
                <div className="space-y-1">
                  <p className="text-[11px] font-bold text-[#8b95a5] uppercase tracking-wider">
                    Free Donor Screening Perks:
                  </p>
                  <ul className="text-[11px] text-gray-300 space-y-1">
                    {camp.benefits.map((b, bIdx) => (
                      <li key={bIdx} className="flex items-center gap-1.5">
                        <i className="fa-solid fa-circle-check text-emerald-400 text-[10px]"></i>
                        {b}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Book Button */}
              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={() => onBookCamp(camp)}
                className="w-full mt-5 py-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs tracking-wider uppercase transition-all shadow-lg shadow-red-950 flex items-center justify-center gap-2 cursor-pointer border border-red-500/50"
              >
                <i className="fa-solid fa-calendar-check"></i>
                Book Donor Slot
              </motion.button>
            </motion.div>
          );
        })}
      </div>
    </motion.div>
  );
};
