import React from 'react';
import { motion } from 'motion/react';

interface ServicesViewProps {
  onNavigate: (view: string) => void;
  onRequestBlood: () => void;
  onTrackRequest: () => void;
  onRegisterDonor: () => void;
  onEmergencySOS: () => void;
}

export const ServicesView: React.FC<ServicesViewProps> = ({
  onNavigate,
  onRequestBlood,
  onTrackRequest,
  onRegisterDonor,
  onEmergencySOS,
}) => {
  const serviceCards = [
    {
      title: 'Request Blood',
      desc: 'Send an emergency request to hospitals and nearby verified donors without delay. Instant coordination.',
      icon: 'fa-solid fa-droplet',
      action: onRequestBlood,
      btnText: 'Broadcast Request',
      badge: 'URGENT',
      color: 'text-red-500',
    },
    {
      title: 'Find Donors',
      desc: 'Connect with compatible, active donors filtered by blood type, city, and readiness to help right now.',
      icon: 'fa-solid fa-magnifying-glass',
      action: () => onNavigate('donors'),
      btnText: 'Search Community',
      badge: 'SEARCH',
      color: 'text-red-400',
    },
    {
      title: 'Track Requests',
      desc: 'Stay updated on your blood request status in one unified dashboard: broadcast, donor responses, and transit.',
      icon: 'fa-solid fa-route',
      action: onTrackRequest,
      btnText: 'Open Tracker',
      badge: 'REAL-TIME',
      color: 'text-red-400',
    },
    {
      title: 'Donation Camps',
      desc: 'Discover upcoming voluntary donation drives, reserve comfortable slots, and receive donor health perks.',
      icon: 'fa-solid fa-tent',
      action: () => onNavigate('camps'),
      btnText: 'Explore Drives',
      badge: 'DRIVES',
      color: 'text-red-400',
    },
    {
      title: 'Emergency Support',
      desc: '24/7 dedicated hospital hotline, rapid ambulance coordination, and immediate clinical guidance.',
      icon: 'fa-solid fa-truck-medical',
      action: onEmergencySOS,
      btnText: '24/7 SOS Desk',
      badge: 'HOTLINE',
      color: 'text-red-500',
      isEmergency: true,
    },
    {
      title: 'Donor Registration',
      desc: 'Join our growing network of certified blood donors and get notified whenever a matching patient is in need.',
      icon: 'fa-solid fa-user-plus',
      action: onRegisterDonor,
      btnText: 'Join Network',
      badge: 'JOIN',
      color: 'text-red-400',
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="w-full space-y-12 pb-16"
    >
      {/* ================= HERO ================= */}
      <section className="text-center pt-2 max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-950/40 border border-red-800/40 text-red-400 text-xs font-bold tracking-wider uppercase mb-3">
          <i className="fa-solid fa-hand-holding-medical"></i> Full Emergency Portfolio
        </div>
        <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight mb-3">
          HOW WE CAN <span className="shimmer-text">HELP.</span>
        </h1>
        <p className="text-sm sm:text-base text-[#8b95a5]">
          Whether you are ready to donate or searching for urgent medical support, BloodCare gives you a clear, instant place to begin.
        </p>
      </section>

      {/* ================= 6 INTERACTIVE SERVICE CARDS ================= */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {serviceCards.map((card, idx) => (
          <motion.div
            key={card.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: idx * 0.08 }}
            whileHover={{ y: -6, scale: 1.02 }}
            onClick={card.action}
            className={`group p-7 glass-panel rounded-2xl transition-all duration-300 hover:border-red-500/70 hover:shadow-2xl hover:shadow-red-950/50 cursor-pointer flex flex-col justify-between relative overflow-hidden ${
              card.isEmergency ? 'border-red-600/40' : ''
            }`}
          >
            {/* Top accent highlight */}
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-red-600/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

            <div>
              <div className="flex items-center justify-between mb-4">
                <div
                  className={`w-14 h-14 rounded-2xl flex items-center justify-center text-2xl transition-all duration-300 group-hover:scale-110 shadow-lg ${
                    card.isEmergency
                      ? 'bg-red-600 text-white animate-pulse'
                      : 'bg-red-600/15 group-hover:bg-red-600 text-red-500 group-hover:text-white'
                  }`}
                >
                  <i className={card.icon}></i>
                </div>
                <span className="px-2.5 py-0.5 rounded text-[10px] font-black tracking-wider bg-black/40 border border-white/5 text-gray-300">
                  {card.badge}
                </span>
              </div>

              <h2 className="text-xl font-bold text-white group-hover:text-red-400 transition-colors mb-2">
                {card.title}
              </h2>
              <p className="text-xs text-[#8b95a5] leading-relaxed">
                {card.desc}
              </p>
            </div>

            <div className="mt-6 pt-4 border-t border-white/5 flex items-center justify-between text-xs font-bold text-red-500">
              <span>{card.btnText}</span>
              <i className="fa-solid fa-arrow-right group-hover:translate-x-1.5 transition-transform"></i>
            </div>
          </motion.div>
        ))}
      </section>

      {/* ================= WHY CHOOSE BLOODCARE ================= */}
      <section className="glass-panel rounded-3xl p-8 sm:p-10 space-y-8 border border-white/10">
        <div className="text-center max-w-xl mx-auto">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white mb-2">
            Why Choose BloodCare?
          </h2>
          <p className="text-xs sm:text-sm text-[#8b95a5]">
            Making blood donation and emergency blood requests simple, transparent, and swift for everyone.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <motion.div
            whileHover={{ y: -4 }}
            className="p-6 bg-[#080b11] border border-white/5 hover:border-red-500/40 rounded-2xl text-center space-y-3 transition-colors"
          >
            <div className="w-12 h-12 mx-auto rounded-full bg-red-950/60 text-red-400 flex items-center justify-center text-xl shadow-lg shadow-red-950/30">
              <i className="fa-solid fa-bolt"></i>
            </div>
            <h3 className="text-lg font-bold text-white">Quick &amp; Simple</h3>
            <p className="text-xs text-[#8b95a5] leading-relaxed">
              Find donors and request blood with zero red tape through an easy-to-use, rapid digital interface.
            </p>
          </motion.div>

          <motion.div
            whileHover={{ y: -4 }}
            className="p-6 bg-[#080b11] border border-white/5 hover:border-red-500/40 rounded-2xl text-center space-y-3 transition-colors"
          >
            <div className="w-12 h-12 mx-auto rounded-full bg-red-950/60 text-red-400 flex items-center justify-center text-xl shadow-lg shadow-red-950/30">
              <i className="fa-solid fa-shield-heart"></i>
            </div>
            <h3 className="text-lg font-bold text-white">Trusted Community</h3>
            <p className="text-xs text-[#8b95a5] leading-relaxed">
              Direct verification of blood groups, voluntary donors, and hospital requests prevents misinformation.
            </p>
          </motion.div>

          <motion.div
            whileHover={{ y: -4 }}
            className="p-6 bg-[#080b11] border border-white/5 hover:border-red-500/40 rounded-2xl text-center space-y-3 transition-colors"
          >
            <div className="w-12 h-12 mx-auto rounded-full bg-red-950/60 text-red-400 flex items-center justify-center text-xl shadow-lg shadow-red-950/30">
              <i className="fa-solid fa-heart-pulse animate-heartbeat"></i>
            </div>
            <h3 className="text-lg font-bold text-white">Save Lives</h3>
            <p className="text-xs text-[#8b95a5] leading-relaxed">
              Every single successful blood donation can give up to 3 critically ill patients another chance at life.
            </p>
          </motion.div>
        </div>
      </section>

      {/* ================= CALL TO ACTION ================= */}
      <section className="bg-gradient-to-r from-red-950/90 via-[#181d29] to-[#0c0f17] border border-red-800/60 rounded-3xl p-8 sm:p-10 flex flex-col md:flex-row items-center justify-between gap-6 shadow-2xl relative overflow-hidden">
        <div className="space-y-2 text-center md:text-left relative z-10">
          <p className="text-xs font-bold text-red-400 tracking-widest uppercase">READY TO HELP?</p>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white">One donation can change everything.</h2>
          <p className="text-xs sm:text-sm text-gray-300">
            Register today and be the reason someone gets another tomorrow.
          </p>
        </div>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.96 }}
          onClick={onRegisterDonor}
          className="px-8 py-3.5 bg-red-600 hover:bg-red-700 text-white font-bold text-sm tracking-wider uppercase rounded-xl shadow-xl shadow-red-950 transition-all shrink-0 cursor-pointer border border-red-500/50"
        >
          Register as a Donor
        </motion.button>
      </section>
    </motion.div>
  );
};
