import React from 'react';
import { motion } from 'motion/react';

interface AboutViewProps {
  onRegisterDonor: () => void;
  onNavigate: (view: string) => void;
}

export const AboutView: React.FC<AboutViewProps> = ({
  onRegisterDonor,
  onNavigate,
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="w-full space-y-12 pb-16"
    >
      {/* ================= HERO ================= */}
      <section className="flex flex-col lg:flex-row items-center justify-between gap-8 pt-4">
        <div className="flex-1 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-red-950/40 border border-red-800/40 text-red-400 text-xs font-bold tracking-wider uppercase">
            <i className="fa-solid fa-droplet text-red-500"></i> The Mission Behind BloodCare
          </div>
          <h1 className="text-4xl sm:text-6xl font-black text-white tracking-tight leading-tight">
            EVERY DROP<br />
            <span className="shimmer-text">TELLS A STORY.</span>
          </h1>
          <p className="text-sm sm:text-base text-gray-300 leading-relaxed max-w-xl">
            BloodCare brings donors, hospitals, and families together when every moment matters. One simple decision to donate can give a patient in emergency a second chance at life.
          </p>

          <div className="pt-2 flex flex-wrap gap-3">
            <motion.button
              whileHover={{ scale: 1.04 }}
              whileTap={{ scale: 0.96 }}
              onClick={onRegisterDonor}
              className="px-6 py-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs tracking-wider uppercase shadow-xl shadow-red-950 transition-all cursor-pointer border border-red-500/50"
            >
              Become a Donor
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.04 }}
              whileTap={{ scale: 0.96 }}
              onClick={() => onNavigate('services')}
              className="px-6 py-3 rounded-xl glass-panel text-gray-300 hover:text-white font-bold text-xs tracking-wider uppercase transition-all cursor-pointer"
            >
              Explore Our Services
            </motion.button>
          </div>
        </div>

        {/* 3D SVG Blood Drop Graphic with Glowing Halo */}
        <div className="w-52 sm:w-64 h-64 sm:h-76 animate-float shrink-0 flex items-center justify-center relative">
          <div className="absolute inset-0 bg-red-600/20 rounded-full blur-[70px] pointer-events-none" />
          <svg
            className="w-full h-full filter drop-shadow-[0_0_40px_rgba(230,0,0,0.65)] relative z-10"
            viewBox="0 0 200 270"
            aria-label="Blood drop"
          >
            <defs>
              <radialGradient id="aboutDropGrad" cx="30%" cy="30%" r="70%">
                <stop offset="0%" stopColor="#ff4747" />
                <stop offset="0.45" stopColor="#cc0000" />
                <stop offset="1" stopColor="#330000" />
              </radialGradient>
            </defs>
            <path
              d="M100 10S20 120 20 180a80 80 0 0 0 160 0C180 120 100 10 100 10Z"
              fill="url(#aboutDropGrad)"
            />
            <path
              d="M100 42 60 140 35 180 100 240 165 180 140 140Z"
              fill="none"
              stroke="rgba(255,180,180,.85)"
              strokeDasharray="8 4"
              strokeWidth="1.5"
            />
            <g fill="#fff">
              <circle cx="100" cy="42" r="3.5" className="animate-node-pulse" />
              <circle cx="60" cy="140" r="3.5" className="animate-node-pulse" />
              <circle cx="140" cy="140" r="3.5" className="animate-node-pulse" />
              <circle cx="35" cy="180" r="3.5" className="animate-node-pulse" />
              <circle cx="165" cy="180" r="3.5" className="animate-node-pulse" />
              <circle cx="100" cy="240" r="3.5" className="animate-node-pulse" />
            </g>
          </svg>
        </div>
      </section>

      {/* ================= ABOUT GRID ================= */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* Main Panel */}
        <motion.div
          whileHover={{ y: -3 }}
          className="lg:col-span-5 bg-gradient-to-br from-[#181d29] via-[#12161f] to-[#0a0d14] border border-white/10 hover:border-red-500/40 rounded-3xl p-8 flex flex-col justify-between space-y-6 shadow-2xl relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />

          <div className="space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-red-600/20 text-red-500 flex items-center justify-center text-2xl shadow-lg shadow-red-950/40 animate-heartbeat">
              <i className="fa-solid fa-heart-pulse"></i>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white leading-snug">
              Care that reaches people faster.
            </h2>
            <p className="text-xs sm:text-sm text-[#8b95a5] leading-relaxed">
              We make blood donation easier to understand, easier to access, and safer for everyone involved — from first-time student donors to hospital emergency trauma units.
            </p>
          </div>

          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={onRegisterDonor}
            className="w-full py-3.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs tracking-wider uppercase transition-all shadow-xl shadow-red-950 cursor-pointer border border-red-500/50"
          >
            Become a Donor Today
          </motion.button>
        </motion.div>

        {/* 4 Feature Cards */}
        <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-4">
          <motion.div
            whileHover={{ y: -4, scale: 1.02 }}
            className="p-6 glass-panel rounded-2xl space-y-2.5 transition-all hover:border-red-500/40"
          >
            <div className="w-10 h-10 rounded-xl bg-red-600/15 text-red-400 flex items-center justify-center text-lg shadow-md">
              <i className="fa-solid fa-shield-heart"></i>
            </div>
            <h3 className="text-base font-bold text-white">Safe Donations</h3>
            <p className="text-xs text-[#8b95a5] leading-relaxed">
              Clear medical eligibility guidance, sterile equipment assurance, and pre-donation screening.
            </p>
          </motion.div>

          <motion.div
            whileHover={{ y: -4, scale: 1.02 }}
            className="p-6 glass-panel rounded-2xl space-y-2.5 transition-all hover:border-red-500/40"
          >
            <div className="w-10 h-10 rounded-xl bg-red-600/15 text-red-400 flex items-center justify-center text-lg shadow-md">
              <i className="fa-solid fa-bolt"></i>
            </div>
            <h3 className="text-base font-bold text-white">Quick Support</h3>
            <p className="text-xs text-[#8b95a5] leading-relaxed">
              Instant matching algorithm connects patients to verified nearby blood donors in minutes.
            </p>
          </motion.div>

          <motion.div
            whileHover={{ y: -4, scale: 1.02 }}
            className="p-6 glass-panel rounded-2xl space-y-2.5 transition-all hover:border-red-500/40"
          >
            <div className="w-10 h-10 rounded-xl bg-red-600/15 text-red-400 flex items-center justify-center text-lg shadow-md">
              <i className="fa-solid fa-users"></i>
            </div>
            <h3 className="text-base font-bold text-white">Community Driven</h3>
            <p className="text-xs text-[#8b95a5] leading-relaxed">
              Powered by thousands of local voluntary heroes ready to step forward when duty calls.
            </p>
          </motion.div>

          <motion.div
            whileHover={{ y: -4, scale: 1.02 }}
            className="p-6 glass-panel rounded-2xl space-y-2.5 transition-all hover:border-red-500/40"
          >
            <div className="w-10 h-10 rounded-xl bg-red-600/15 text-red-400 flex items-center justify-center text-lg shadow-md">
              <i className="fa-solid fa-route"></i>
            </div>
            <h3 className="text-base font-bold text-white">Live Tracking</h3>
            <p className="text-xs text-[#8b95a5] leading-relaxed">
              Full transparency on request progress from broadcast to donor match and clinical transfusion.
            </p>
          </motion.div>
        </div>
      </section>
    </motion.div>
  );
};
