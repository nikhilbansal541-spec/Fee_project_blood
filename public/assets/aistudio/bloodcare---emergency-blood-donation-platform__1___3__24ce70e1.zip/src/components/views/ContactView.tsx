import React, { useState } from 'react';
import { motion } from 'motion/react';

interface ContactViewProps {
  onEmergencySOS: () => void;
}

export const ContactView: React.FC<ContactViewProps> = ({ onEmergencySOS }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [statusMsg, setStatusMsg] = useState<{ text: string; isError: boolean } | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !message.trim()) {
      setStatusMsg({ text: 'Please fill in all fields before sending.', isError: true });
      return;
    }

    const newTicket = 'TIC-' + Math.floor(1000 + Math.random() * 9000);
    setStatusMsg({
      text: `Thanks, ${name}! Your support ticket #${newTicket} has been received. Our medical coordinator will follow up via email within 24 hours.`,
      isError: false,
    });

    setName('');
    setEmail('');
    setMessage('');
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="w-full space-y-10 pb-16"
    >
      {/* ================= HERO ================= */}
      <section className="text-center pt-2 max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-red-950/40 border border-red-800/40 text-red-400 text-xs font-bold tracking-wider uppercase mb-3">
          <i className="fa-solid fa-headset"></i> 24/7 Support Desk
        </div>
        <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight mb-3">
          Contact <span className="shimmer-text">Us.</span>
        </h1>
        <p className="text-sm sm:text-base text-[#8b95a5]">
          Have a question, need urgent help, or want to volunteer? Our emergency support team connects donors, patients, and hospitals around the clock.
        </p>
      </section>

      {/* ================= CONTACT GRID ================= */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Info Cards (4 items) */}
        <div className="lg:col-span-5 grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Phone */}
          <motion.a
            whileHover={{ y: -4, scale: 1.02 }}
            href="tel:+919876543210"
            className="p-5 glass-panel rounded-2xl transition-all group block border border-white/5 hover:border-red-500/50"
          >
            <div className="w-11 h-11 rounded-xl bg-red-600/15 group-hover:bg-red-600 text-red-500 group-hover:text-white flex items-center justify-center text-lg mb-3 transition-colors shadow-md">
              <i className="fa-solid fa-phone"></i>
            </div>
            <h3 className="text-sm font-bold text-white mb-1">Phone Helpline</h3>
            <p className="text-xs text-[#8b95a5] font-mono group-hover:text-red-400 transition-colors">
              +91 98765 43210
            </p>
          </motion.a>

          {/* Email */}
          <motion.a
            whileHover={{ y: -4, scale: 1.02 }}
            href="mailto:support@bloodcare.com"
            className="p-5 glass-panel rounded-2xl transition-all group block border border-white/5 hover:border-red-500/50"
          >
            <div className="w-11 h-11 rounded-xl bg-red-600/15 group-hover:bg-red-600 text-red-500 group-hover:text-white flex items-center justify-center text-lg mb-3 transition-colors shadow-md">
              <i className="fa-solid fa-envelope"></i>
            </div>
            <h3 className="text-sm font-bold text-white mb-1">Support Email</h3>
            <p className="text-xs text-[#8b95a5] group-hover:text-red-400 transition-colors truncate">
              support@bloodcare.com
            </p>
          </motion.a>

          {/* Location */}
          <motion.div
            whileHover={{ y: -4, scale: 1.02 }}
            className="p-5 glass-panel rounded-2xl border border-white/5"
          >
            <div className="w-11 h-11 rounded-xl bg-red-600/15 text-red-500 flex items-center justify-center text-lg mb-3">
              <i className="fa-solid fa-location-dot"></i>
            </div>
            <h3 className="text-sm font-bold text-white mb-1">Central Hub</h3>
            <p className="text-xs text-[#8b95a5]">Sector 16, Chandigarh, India</p>
          </motion.div>

          {/* Working Hours */}
          <motion.div
            whileHover={{ y: -4, scale: 1.02 }}
            className="p-5 glass-panel rounded-2xl border border-white/5"
          >
            <div className="w-11 h-11 rounded-xl bg-red-600/15 text-red-500 flex items-center justify-center text-lg mb-3">
              <i className="fa-solid fa-clock"></i>
            </div>
            <h3 className="text-sm font-bold text-white mb-1">Support Hours</h3>
            <p className="text-xs text-[#8b95a5]">24/7 for Emergencies</p>
          </motion.div>

          {/* Direct call button */}
          <div className="sm:col-span-2 pt-2">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={onEmergencySOS}
              className="w-full py-3.5 rounded-xl bg-red-950/70 hover:bg-red-900/90 border border-red-700/80 text-red-300 hover:text-white font-bold text-xs tracking-wider uppercase transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xl"
            >
              <i className="fa-solid fa-truck-medical animate-pulse"></i>
              Open 24/7 Emergency Dispatch
            </motion.button>
          </div>
        </div>

        {/* Message Form Card */}
        <div className="lg:col-span-7 glass-panel rounded-3xl p-6 sm:p-8 shadow-2xl border border-white/10 hover:border-red-500/40 transition-all">
          <div className="mb-5">
            <h2 className="text-2xl font-bold text-white tracking-tight mb-1">
              Send Us a Message
            </h2>
            <p className="text-xs text-[#8b95a5]">
              We usually respond within a few hours. For critical blood shortages, please use the 24/7 hotline.
            </p>
          </div>

          {statusMsg && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className={`p-4 rounded-xl text-xs mb-5 border ${
                statusMsg.isError
                  ? 'bg-red-950/70 border-red-800 text-red-200'
                  : 'bg-emerald-950/70 border-emerald-800 text-emerald-200'
              }`}
            >
              {statusMsg.text}
            </motion.div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-[#8b95a5] uppercase tracking-wider mb-1.5">
                Your Full Name *
              </label>
              <input
                type="text"
                placeholder="Enter your name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full h-11 px-3.5 bg-[#06080c] border border-[#1e2533] focus:border-red-500 rounded-xl text-xs text-white outline-none transition-colors"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#8b95a5] uppercase tracking-wider mb-1.5">
                Email Address *
              </label>
              <input
                type="email"
                placeholder="Enter your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full h-11 px-3.5 bg-[#06080c] border border-[#1e2533] focus:border-red-500 rounded-xl text-xs text-white outline-none transition-colors"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#8b95a5] uppercase tracking-wider mb-1.5">
                Message / Inquiry *
              </label>
              <textarea
                rows={4}
                placeholder="How can we help you? Describe hospital requirement, donor inquiry, or camp organization..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="w-full p-3.5 bg-[#06080c] border border-[#1e2533] focus:border-red-500 rounded-xl text-xs text-white outline-none resize-none transition-colors"
                required
              />
            </div>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              type="submit"
              className="w-full py-3.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs tracking-wider uppercase shadow-xl shadow-red-950 transition-all cursor-pointer flex items-center justify-center gap-2 border border-red-500/50"
            >
              <i className="fa-solid fa-paper-plane"></i>
              Send Message
            </motion.button>
          </form>
        </div>
      </section>

      {/* ================= EMERGENCY STRIP WITH PULSING HALO ================= */}
      <motion.section
        whileHover={{ scale: 1.01 }}
        onClick={onEmergencySOS}
        className="bg-gradient-to-r from-red-950/90 via-[#181d29] to-[#0a0d14] border border-red-700/80 hover:border-red-500 rounded-3xl p-6 sm:p-8 flex items-center justify-between gap-6 cursor-pointer shadow-2xl transition-all relative overflow-hidden"
      >
        <div className="space-y-1 relative z-10">
          <h3 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-red-500 animate-ping"></span>
            Need blood urgently?
          </h3>
          <p className="text-xs sm:text-sm text-gray-300">
            Skip the form — call our 24/7 emergency hotline for immediate hospital blood dispatch coordination.
          </p>
        </div>
        <div className="w-14 h-14 rounded-2xl bg-red-600/20 text-red-400 flex items-center justify-center text-3xl shrink-0 animate-bounce relative z-10">
          <i className="fa-solid fa-truck-medical"></i>
        </div>
      </motion.section>
    </motion.div>
  );
};
