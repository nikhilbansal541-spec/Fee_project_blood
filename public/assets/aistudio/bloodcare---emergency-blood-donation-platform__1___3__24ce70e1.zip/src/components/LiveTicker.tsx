import React from 'react';

export const LiveTicker: React.FC = () => {
  const tickerItems = [
    { type: 'alert', text: '🚨 CRITICAL: 2 Units O+ Needed at PGI Hospital Chandigarh (Trauma Center)' },
    { type: 'success', text: '✓ 3 Donors matched for surgery at Fortis Mohali' },
    { type: 'info', text: '📍 Next Mega Blood Camp: Sector 16 Rose Garden Hall (2 Days Left)' },
    { type: 'live', text: '⚡ 8,920+ Certified Donors On Standby Across Tricity' },
    { type: 'alert', text: '📞 24/7 Immediate Helpline Active: +91 98765 43210' },
  ];

  return (
    <div className="w-full bg-[#080b11]/90 border-y border-white/5 overflow-hidden py-2 backdrop-blur-md relative z-20">
      <div className="animate-marquee flex items-center gap-8 whitespace-nowrap text-xs">
        {tickerItems.concat(tickerItems).map((item, idx) => (
          <div key={idx} className="flex items-center gap-2.5 text-gray-300 select-none">
            <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse"></span>
            <span
              className={`font-semibold tracking-wide ${
                item.type === 'alert'
                  ? 'text-red-400'
                  : item.type === 'success'
                  ? 'text-emerald-400'
                  : 'text-gray-300'
              }`}
            >
              {item.text}
            </span>
            <span className="text-gray-600 mx-2">•</span>
          </div>
        ))}
      </div>
    </div>
  );
};
