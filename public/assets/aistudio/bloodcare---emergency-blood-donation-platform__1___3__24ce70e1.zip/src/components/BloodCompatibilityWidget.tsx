import React, { useState } from 'react';
import { BloodGroup } from '../types';
import { BLOOD_COMPATIBILITY_CHART } from '../data/initialData';

const ALL_GROUPS: BloodGroup[] = ['O-', 'O+', 'A-', 'A+', 'B-', 'B+', 'AB-', 'AB+'];

export const BloodCompatibilityWidget: React.FC = () => {
  const [selectedGroup, setSelectedGroup] = useState<BloodGroup>('O+');
  const [activeTab, setActiveTab] = useState<'give' | 'receive'>('give');

  const compatibility = BLOOD_COMPATIBILITY_CHART[selectedGroup];
  const activeTargets = activeTab === 'give' ? compatibility.giveTo : compatibility.receiveFrom;

  return (
    <div className="w-full glass-panel rounded-2xl p-5 border border-white/10 hover:border-red-500/30 transition-all shadow-xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 border-b border-white/5 pb-3">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-red-600/20 text-red-500 flex items-center justify-center text-lg animate-heartbeat">
            <i className="fa-solid fa-heart-pulse"></i>
          </div>
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              Interactive Blood Compatibility Radar
              <span className="px-1.5 py-0.5 text-[9px] font-extrabold uppercase bg-red-950 text-red-400 border border-red-800 rounded">
                Live Match
              </span>
            </h3>
            <p className="text-[11px] text-[#8b95a5]">Select any blood group to simulate emergency transfusion matching</p>
          </div>
        </div>

        {/* Tab switch */}
        <div className="flex bg-[#07090e] p-1 rounded-xl border border-white/10 text-xs self-start sm:self-auto">
          <button
            onClick={() => setActiveTab('give')}
            className={`px-3 py-1 rounded-lg font-bold transition-all ${
              activeTab === 'give'
                ? 'bg-red-600 text-white shadow-md shadow-red-950'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Can Give To
          </button>
          <button
            onClick={() => setActiveTab('receive')}
            className={`px-3 py-1 rounded-lg font-bold transition-all ${
              activeTab === 'receive'
                ? 'bg-red-600 text-white shadow-md shadow-red-950'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Can Receive From
          </button>
        </div>
      </div>

      {/* Blood Group Selectors */}
      <div className="space-y-3">
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          <span className="text-[11px] font-semibold text-[#8b95a5] shrink-0 uppercase tracking-wider">
            Choose Blood:
          </span>
          {ALL_GROUPS.map((bg) => (
            <button
              key={bg}
              onClick={() => setSelectedGroup(bg)}
              className={`px-3 py-1.5 rounded-lg text-xs font-black transition-all cursor-pointer ${
                selectedGroup === bg
                  ? 'bg-red-600 text-white shadow-[0_0_15px_rgba(230,0,0,0.6)] scale-105'
                  : 'bg-[#0e121a] text-gray-300 hover:text-white border border-white/5 hover:border-white/20'
              }`}
            >
              {bg}
            </button>
          ))}
        </div>

        {/* Interactive Compatibility Stream Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-8 gap-2 pt-2">
          {ALL_GROUPS.map((target) => {
            const isMatch = activeTargets.includes(target);
            return (
              <div
                key={target}
                className={`p-2.5 rounded-xl text-center border transition-all duration-300 ${
                  isMatch
                    ? 'bg-gradient-to-b from-red-950/80 to-[#161b26] border-red-500/70 shadow-lg shadow-red-950/40 scale-105'
                    : 'bg-[#080b11] border-white/5 opacity-40'
                }`}
              >
                <div
                  className={`text-lg font-black ${
                    isMatch ? 'text-white text-glow-red' : 'text-gray-500'
                  }`}
                >
                  {target}
                </div>
                <div className="text-[10px] mt-1 font-semibold flex items-center justify-center gap-1">
                  {isMatch ? (
                    <span className="text-emerald-400 flex items-center gap-0.5">
                      <i className="fa-solid fa-check text-[9px]"></i> Compatible
                    </span>
                  ) : (
                    <span className="text-gray-500">Incompatible</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Quick Context Tip */}
        <div className="p-2.5 bg-black/40 rounded-xl border border-white/5 flex items-center justify-between text-[11px] text-[#8b95a5]">
          <span>
            {selectedGroup === 'O-' ? (
              <strong className="text-red-400">🌟 O- Negative is the Universal Red Cell Donor</strong>
            ) : selectedGroup === 'AB+' ? (
              <strong className="text-emerald-400">🛡 AB+ Positive is the Universal Recipient</strong>
            ) : (
              <span>
                Matching <strong className="text-white">{selectedGroup}</strong> with{' '}
                <strong className="text-red-400">{activeTargets.length} compatible blood groups</strong>
              </span>
            )}
          </span>
          <span className="text-gray-400 hidden sm:inline">Clinical Grade Cross-Match Guide</span>
        </div>
      </div>
    </div>
  );
};
