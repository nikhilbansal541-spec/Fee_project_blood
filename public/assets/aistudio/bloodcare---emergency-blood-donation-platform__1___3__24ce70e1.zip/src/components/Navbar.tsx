import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { User } from '../types';
import { sfx } from '../utils/audio';

interface NavbarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  onRequestBlood: () => void;
  onEmergencySOS: () => void;
  onOpenLogin: () => void;
  user: User | null;
  onLogout: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onNavigate,
  onRequestBlood,
  onEmergencySOS,
  onOpenLogin,
  user,
  onLogout,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [audioEnabled, setAudioEnabled] = useState(sfx.enabled);

  const toggleAudio = () => {
    sfx.enabled = !sfx.enabled;
    setAudioEnabled(sfx.enabled);
    if (sfx.enabled) {
      sfx.playClick();
    }
  };

  const navLinks = [
    { id: 'home', label: 'Home', icon: 'fa-solid fa-house' },
    { id: 'about', label: 'About', icon: 'fa-solid fa-circle-info' },
    { id: 'services', label: 'Services', icon: 'fa-solid fa-hand-holding-medical' },
    { id: 'donors', label: 'Donors', icon: 'fa-solid fa-users' },
    { id: 'camps', label: 'Camps', icon: 'fa-solid fa-tent' },
    { id: 'contact', label: 'Contact', icon: 'fa-solid fa-envelope' },
  ];

  const handleLinkClick = (id: string) => {
    sfx.playClick();
    onNavigate(id);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 w-full h-[74px] flex items-center justify-between border-b border-white/5 bg-[#05070a]/80 backdrop-blur-xl px-4 sm:px-8 transition-colors">
      {/* Logo with pulsing glow */}
      <motion.div
        whileHover={{ scale: 1.03 }}
        whileTap={{ scale: 0.97 }}
        onClick={() => handleLinkClick('home')}
        className="flex items-center gap-2.5 text-xl sm:text-2xl font-black cursor-pointer select-none group"
      >
        <div className="relative flex items-center justify-center">
          <i className="fa-solid fa-droplet text-red-600 filter drop-shadow-[0_0_12px_rgba(230,0,0,0.8)] group-hover:scale-110 transition-transform"></i>
          <span className="absolute -inset-1 rounded-full bg-red-600/20 blur-sm group-hover:bg-red-600/40 pointer-events-none" />
        </div>
        <span className="text-white tracking-tight font-extrabold flex items-center">
          Blood<span className="text-red-500">Care</span>
        </span>
      </motion.div>

      {/* Desktop Navigation Links */}
      <nav className="hidden md:flex items-center gap-1.5 lg:gap-2">
        {navLinks.map((link) => {
          const isActive = currentView === link.id;
          return (
            <motion.button
              key={link.id}
              whileHover={{ y: -1 }}
              whileTap={{ scale: 0.96 }}
              onClick={() => handleLinkClick(link.id)}
              className={`px-3.5 py-1.5 rounded-xl text-xs lg:text-sm font-semibold transition-all duration-200 cursor-pointer flex items-center gap-1.5 ${
                isActive
                  ? 'bg-red-600 text-white shadow-[0_0_18px_rgba(230,0,0,0.55)] border border-red-500/60'
                  : 'text-gray-300 hover:text-white hover:bg-white/5 border border-transparent'
              }`}
            >
              <span>{link.label}</span>
            </motion.button>
          );
        })}
      </nav>

      {/* Right Action Buttons */}
      <div className="hidden sm:flex items-center gap-3">
        {/* Sound FX Audio Visualizer Toggle */}
        <motion.button
          whileHover={{ scale: 1.08 }}
          whileTap={{ scale: 0.92 }}
          onClick={toggleAudio}
          title={audioEnabled ? 'Sound FX On (Click to Mute)' : 'Sound FX Muted (Click to Enable)'}
          className={`p-2 rounded-xl text-xs border transition-all cursor-pointer flex items-center gap-1.5 ${
            audioEnabled
              ? 'bg-red-950/40 border-red-700/60 text-red-400 hover:text-red-300'
              : 'bg-white/5 border-white/10 text-gray-500 hover:text-gray-300'
          }`}
        >
          {audioEnabled ? (
            <div className="flex items-end gap-[2px] h-3.5 px-0.5">
              <span className="w-[3px] bg-red-400 rounded-full animate-[pulse_0.6s_ease-in-out_infinite] h-2"></span>
              <span className="w-[3px] bg-red-400 rounded-full animate-[pulse_0.8s_ease-in-out_infinite_0.2s] h-3.5"></span>
              <span className="w-[3px] bg-red-400 rounded-full animate-[pulse_0.5s_ease-in-out_infinite_0.4s] h-2.5"></span>
            </div>
          ) : (
            <i className="fa-solid fa-volume-xmark"></i>
          )}
        </motion.button>

        {/* Emergency SOS Callout */}
        <motion.button
          whileHover={{ scale: 1.04 }}
          whileTap={{ scale: 0.96 }}
          onClick={() => {
            sfx.playAlert();
            onEmergencySOS();
          }}
          title="24/7 Emergency Blood Helpline"
          className="px-3 py-1.5 rounded-xl bg-red-950/60 border border-red-800/80 text-red-300 hover:text-white hover:bg-red-900/60 text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shadow-md shadow-red-950/40"
        >
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-red-600"></span>
          </span>
          24/7 SOS
        </motion.button>

        {/* Request Blood Quick Button */}
        <motion.button
          whileHover={{ scale: 1.04 }}
          whileTap={{ scale: 0.96 }}
          onClick={() => {
            sfx.playClick();
            onRequestBlood();
          }}
          className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold tracking-wide shadow-lg shadow-red-950/80 transition-all cursor-pointer flex items-center gap-1.5 border border-red-500/50"
        >
          <i className="fa-solid fa-plus text-[10px]"></i>
          Request Blood
        </motion.button>

        {/* Login or User Profile */}
        {user ? (
          <div className="flex items-center gap-2 pl-2 border-l border-white/10">
            <div className="flex items-center gap-2 px-3 py-1.5 glass-panel rounded-xl text-xs border border-white/10">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span className="font-bold text-white truncate max-w-[100px]">{user.name}</span>
              {user.bloodGroup && (
                <span className="px-1.5 py-0.5 bg-red-950 text-red-400 font-mono text-[10px] font-bold rounded border border-red-900">
                  {user.bloodGroup}
                </span>
              )}
            </div>
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => {
                sfx.playClick();
                onLogout();
              }}
              title="Sign Out"
              className="p-2 text-gray-400 hover:text-red-400 text-xs rounded-xl hover:bg-white/5 cursor-pointer"
            >
              <i className="fa-solid fa-right-from-bracket"></i>
            </motion.button>
          </div>
        ) : (
          <motion.button
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.96 }}
            onClick={() => {
              sfx.playClick();
              onOpenLogin();
            }}
            className="px-4 py-2 rounded-xl border border-red-600/80 text-red-400 hover:bg-red-600 hover:text-white font-bold text-xs tracking-wide transition-all shadow-[0_0_14px_rgba(230,0,0,0.25)] cursor-pointer"
          >
            Login
          </motion.button>
        )}
      </div>

      {/* Mobile Hamburger Toggle */}
      <button
        onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        className="md:hidden text-white p-2 text-xl hover:text-red-500 cursor-pointer"
        aria-label="Toggle Navigation Menu"
      >
        <i className={`fa-solid ${mobileMenuOpen ? 'fa-xmark' : 'fa-bars'}`}></i>
      </button>

      {/* Mobile Dropdown Menu with AnimatePresence */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="absolute top-[74px] left-0 right-0 bg-[#07090e]/95 backdrop-blur-2xl border-b border-white/10 p-5 flex flex-col gap-2.5 md:hidden shadow-2xl z-50"
          >
            {navLinks.map((link) => {
              const isActive = currentView === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => handleLinkClick(link.id)}
                  className={`w-full py-3 px-4 rounded-xl text-left text-sm font-bold transition-all cursor-pointer flex items-center justify-between ${
                    isActive
                      ? 'bg-red-600 text-white shadow-md'
                      : 'text-gray-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <span className="flex items-center gap-2.5">
                    <i className={link.icon}></i>
                    {link.label}
                  </span>
                  {isActive && <i className="fa-solid fa-chevron-right text-xs"></i>}
                </button>
              );
            })}

            <div className="pt-3 border-t border-white/10 flex flex-col gap-2.5">
              <button
                onClick={() => {
                  onRequestBlood();
                  setMobileMenuOpen(false);
                }}
                className="w-full py-3 rounded-xl bg-red-600 text-white font-bold text-xs uppercase tracking-wider"
              >
                <i className="fa-solid fa-plus mr-1.5"></i> Request Blood
              </button>
              <button
                onClick={() => {
                  onEmergencySOS();
                  setMobileMenuOpen(false);
                }}
                className="w-full py-2.5 rounded-xl bg-red-950/70 border border-red-800 text-red-300 font-bold text-xs"
              >
                24/7 Emergency Helpline
              </button>

              {user ? (
                <div className="flex items-center justify-between p-3 bg-white/5 rounded-xl text-xs">
                  <span className="font-bold text-white">Signed in as {user.name}</span>
                  <button
                    onClick={() => {
                      onLogout();
                      setMobileMenuOpen(false);
                    }}
                    className="text-red-400 font-bold"
                  >
                    Logout
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => {
                    onOpenLogin();
                    setMobileMenuOpen(false);
                  }}
                  className="w-full py-3 rounded-xl border border-red-600 text-white font-bold text-xs"
                >
                  Login to BloodCare
                </button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};
