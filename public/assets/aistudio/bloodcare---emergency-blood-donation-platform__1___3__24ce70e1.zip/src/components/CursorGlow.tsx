import React, { useEffect, useState } from 'react';

export const CursorGlow: React.FC = () => {
  const [pos, setPos] = useState({ x: -200, y: -200 });
  const [trailingPos, setTrailingPos] = useState({ x: -200, y: -200 });
  const [isHovering, setIsHovering] = useState(false);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    // Only run on non-touch devices
    if (window.matchMedia('(pointer: coarse)').matches) return;

    let targetX = -200;
    let targetY = -200;
    let currentX = -200;
    let currentY = -200;
    let animId: number;

    const onMouseMove = (e: MouseEvent) => {
      targetX = e.clientX;
      targetY = e.clientY;
      setPos({ x: e.clientX, y: e.clientY });
      if (!visible) setVisible(true);

      const target = e.target as HTMLElement | null;
      if (target) {
        const isClickable = !!target.closest('button, a, select, input, .card, [role="button"], .clickable');
        setIsHovering(isClickable);
      }
    };

    const onMouseLeave = () => {
      setVisible(false);
    };

    const updateTrail = () => {
      currentX += (targetX - currentX) * 0.18;
      currentY += (targetY - currentY) * 0.18;
      setTrailingPos({ x: currentX, y: currentY });
      animId = requestAnimationFrame(updateTrail);
    };

    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseleave', onMouseLeave);
    animId = requestAnimationFrame(updateTrail);

    return () => {
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseleave', onMouseLeave);
      cancelAnimationFrame(animId);
    };
  }, [visible]);

  if (!visible) return null;

  return (
    <>
      {/* Large soft ambient red blur trailing cursor */}
      <div
        className="fixed pointer-events-none z-40 transition-transform duration-75 ease-out rounded-full blur-[45px] -translate-x-1/2 -translate-y-1/2"
        style={{
          left: `${trailingPos.x}px`,
          top: `${trailingPos.y}px`,
          width: isHovering ? '180px' : '110px',
          height: isHovering ? '180px' : '110px',
          background: isHovering
            ? 'radial-gradient(circle, rgba(230, 0, 0, 0.35) 0%, rgba(230, 0, 0, 0) 70%)'
            : 'radial-gradient(circle, rgba(230, 0, 0, 0.18) 0%, rgba(230, 0, 0, 0) 70%)',
        }}
      />

      {/* Crisp small pinpoint halo */}
      <div
        className="fixed pointer-events-none z-50 rounded-full border border-red-500/60 -translate-x-1/2 -translate-y-1/2 transition-all duration-100 ease-out"
        style={{
          left: `${pos.x}px`,
          top: `${pos.y}px`,
          width: isHovering ? '38px' : '14px',
          height: isHovering ? '38px' : '14px',
          background: isHovering ? 'rgba(230, 0, 0, 0.15)' : 'rgba(255, 255, 255, 0.4)',
          boxShadow: isHovering ? '0 0 15px rgba(230, 0, 0, 0.7)' : '0 0 6px rgba(255, 50, 50, 0.5)',
        }}
      />
    </>
  );
};
