import React from 'react';

export const HeartbeatECGBanner: React.FC = () => {
  return (
    <div className="w-full relative py-2 overflow-hidden bg-[#05070a]/60 border-y border-white/5 flex items-center justify-between px-4 sm:px-8">
      {/* Left status */}
      <div className="flex items-center gap-2 text-[11px] font-bold text-gray-400 shrink-0 select-none">
        <span className="w-2 h-2 rounded-full bg-red-500 animate-ping"></span>
        <span className="text-white font-mono tracking-wider">LIVE CARDIAC SYNC</span>
        <span className="text-red-500 font-mono text-[10px] hidden sm:inline">72 BPM • STABLE</span>
      </div>

      {/* SVG Animated ECG Line */}
      <div className="flex-1 max-w-xl mx-4 h-6 relative overflow-hidden">
        <svg
          viewBox="0 0 600 50"
          className="w-full h-full preserve-3d"
          preserveAspectRatio="none"
        >
          <defs>
            <linearGradient id="ecgGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="transparent" />
              <stop offset="45%" stopColor="#e60000" />
              <stop offset="50%" stopColor="#ffffff" />
              <stop offset="55%" stopColor="#ff4d4d" />
              <stop offset="100%" stopColor="transparent" />
            </linearGradient>
            <filter id="ecgGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="2.5" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          {/* Background Dim Guide Path */}
          <path
            d="M 0 25 L 80 25 L 90 15 L 100 35 L 110 25 L 160 25 L 170 5 L 180 45 L 190 20 L 200 25 L 280 25 L 290 15 L 300 35 L 310 25 L 360 25 L 370 5 L 380 45 L 390 20 L 400 25 L 480 25 L 490 15 L 500 35 L 510 25 L 560 25 L 570 5 L 580 45 L 590 20 L 600 25"
            fill="none"
            stroke="rgba(255, 50, 50, 0.15)"
            strokeWidth="1.5"
          />

          {/* Animated Sweeping Bright ECG Line */}
          <path
            d="M 0 25 L 80 25 L 90 15 L 100 35 L 110 25 L 160 25 L 170 5 L 180 45 L 190 20 L 200 25 L 280 25 L 290 15 L 300 35 L 310 25 L 360 25 L 370 5 L 380 45 L 390 20 L 400 25 L 480 25 L 490 15 L 500 35 L 510 25 L 560 25 L 570 5 L 580 45 L 590 20 L 600 25"
            fill="none"
            stroke="url(#ecgGrad)"
            strokeWidth="2.5"
            strokeDasharray="120 480"
            strokeDashoffset="0"
            filter="url(#ecgGlow)"
            className="animate-ecg-sweep"
          />
        </svg>
      </div>

      {/* Right status */}
      <div className="flex items-center gap-2 text-[10px] text-gray-400 font-mono shrink-0 select-none hidden sm:flex">
        <span className="text-emerald-400">● 100% DISPATCH READINESS</span>
      </div>
    </div>
  );
};
