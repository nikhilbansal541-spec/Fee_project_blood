import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { BloodGroup, BloodRequest, Donor } from '../../types';

interface RequestBloodModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (request: Omit<BloodRequest, 'id' | 'timestamp' | 'status' | 'matchedDonorsCount'>) => void;
  donors: Donor[];
}

export const RequestBloodModal: React.FC<RequestBloodModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  donors,
}) => {
  const [patientName, setPatientName] = useState('');
  const [bloodGroup, setBloodGroup] = useState<BloodGroup>('O+');
  const [units, setUnits] = useState(2);
  const [urgency, setUrgency] = useState<'critical' | 'urgent' | 'standard'>('critical');
  const [hospital, setHospital] = useState('');
  const [city, setCity] = useState('Chandigarh');
  const [contactPerson, setContactPerson] = useState('');
  const [phone, setPhone] = useState('');
  const [reason, setReason] = useState('');
  const [error, setError] = useState('');

  if (!isOpen) return null;

  // Count matching donors in system
  const matchingDonors = donors.filter(
    (d) => d.bloodGroup === bloodGroup && d.available
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!patientName.trim() || !hospital.trim() || !contactPerson.trim() || !phone.trim()) {
      setError('Please fill in all required fields (Patient, Hospital, Contact & Phone).');
      return;
    }

    onSubmit({
      patientName: patientName.trim(),
      bloodGroup,
      units,
      urgency,
      hospital: hospital.trim(),
      city: city.trim(),
      contactPerson: contactPerson.trim(),
      phone: phone.trim(),
      reason: reason.trim() || 'Emergency medical requirement',
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <motion.div
        initial={{ opacity: 0, scale: 0.94, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95 }}
        transition={{ type: 'spring', damping: 25, stiffness: 350 }}
        className="relative w-full max-w-xl max-h-[92vh] overflow-y-auto glass-panel border border-white/10 hover:border-red-500/50 rounded-3xl shadow-2xl p-6 text-white transition-all"
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#1e2533] pb-4 mb-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#e60000]/20 flex items-center justify-center text-[#e60000] text-xl">
              <i className="fa-solid fa-droplet"></i>
            </div>
            <div>
              <h2 className="text-xl font-bold tracking-tight">Request Blood Urgently</h2>
              <p className="text-xs text-[#8b95a5]">Post an emergency request to notify nearby verified donors</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors"
          >
            <i className="fa-solid fa-xmark text-lg"></i>
          </button>
        </div>

        {/* Live Matching Donor Alert */}
        <div className="bg-[#181d29] border border-[#e60000]/30 rounded-xl p-3.5 mb-5 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2.5">
            <span className="flex h-2.5 w-2.5 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-600"></span>
            </span>
            <span className="text-[#8b95a5]">
              Active donors available for <strong className="text-white">{bloodGroup}</strong> in our network:
            </span>
          </div>
          <span className="px-2.5 py-1 bg-[#e60000]/20 text-[#ff4d4d] font-bold rounded-md">
            {matchingDonors.length} Verified Donors
          </span>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-950/60 border border-red-800 rounded-lg text-xs text-red-200">
            {error}
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-[#8b95a5] uppercase tracking-wider mb-1.5">
                Patient Full Name *
              </label>
              <input
                type="text"
                placeholder="e.g. Ramesh Kumar"
                value={patientName}
                onChange={(e) => setPatientName(e.target.value)}
                className="w-full h-11 px-3.5 bg-[#06080c] border border-[#1e2533] focus:border-[#e60000] focus:ring-1 focus:ring-[#e60000] rounded-lg text-sm text-white outline-none transition-all"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#8b95a5] uppercase tracking-wider mb-1.5">
                Required Blood Group *
              </label>
              <select
                value={bloodGroup}
                onChange={(e) => setBloodGroup(e.target.value as BloodGroup)}
                className="w-full h-11 px-3 bg-[#06080c] border border-[#1e2533] focus:border-[#e60000] rounded-lg text-sm text-white outline-none cursor-pointer transition-all"
              >
                <option value="A+">A+ (A Positive)</option>
                <option value="A-">A- (A Negative)</option>
                <option value="B+">B+ (B Positive)</option>
                <option value="B-">B- (B Negative)</option>
                <option value="O+">O+ (O Positive)</option>
                <option value="O-">O- (O Negative)</option>
                <option value="AB+">AB+ (AB Positive)</option>
                <option value="AB-">AB- (AB Negative)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-[#8b95a5] uppercase tracking-wider mb-1.5">
                Units Required
              </label>
              <input
                type="number"
                min="1"
                max="10"
                value={units}
                onChange={(e) => setUnits(Number(e.target.value))}
                className="w-full h-11 px-3.5 bg-[#06080c] border border-[#1e2533] focus:border-[#e60000] rounded-lg text-sm text-white outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#8b95a5] uppercase tracking-wider mb-1.5">
                Urgency Level
              </label>
              <div className="grid grid-cols-3 gap-2 h-11">
                <button
                  type="button"
                  onClick={() => setUrgency('critical')}
                  className={`rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1 border ${
                    urgency === 'critical'
                      ? 'bg-[#e60000] text-white border-[#e60000] shadow-md shadow-red-950'
                      : 'bg-[#06080c] text-gray-400 border-[#1e2533] hover:text-white'
                  }`}
                >
                  🚨 Critical
                </button>
                <button
                  type="button"
                  onClick={() => setUrgency('urgent')}
                  className={`rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1 border ${
                    urgency === 'urgent'
                      ? 'bg-amber-600 text-white border-amber-600'
                      : 'bg-[#06080c] text-gray-400 border-[#1e2533] hover:text-white'
                  }`}
                >
                  ⏱ Urgent
                </button>
                <button
                  type="button"
                  onClick={() => setUrgency('standard')}
                  className={`rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1 border ${
                    urgency === 'standard'
                      ? 'bg-blue-600 text-white border-blue-600'
                      : 'bg-[#06080c] text-gray-400 border-[#1e2533] hover:text-white'
                  }`}
                >
                  📅 24 Hours
                </button>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-[#8b95a5] uppercase tracking-wider mb-1.5">
                Hospital / Clinic Name *
              </label>
              <input
                type="text"
                placeholder="e.g. Civil Hospital, Sector 16"
                value={hospital}
                onChange={(e) => setHospital(e.target.value)}
                className="w-full h-11 px-3.5 bg-[#06080c] border border-[#1e2533] focus:border-[#e60000] rounded-lg text-sm text-white outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#8b95a5] uppercase tracking-wider mb-1.5">
                City / Location *
              </label>
              <input
                type="text"
                placeholder="e.g. Chandigarh"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full h-11 px-3.5 bg-[#06080c] border border-[#1e2533] focus:border-[#e60000] rounded-lg text-sm text-white outline-none"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-[#8b95a5] uppercase tracking-wider mb-1.5">
                Contact Person & Relationship *
              </label>
              <input
                type="text"
                placeholder="e.g. Sumit (Brother)"
                value={contactPerson}
                onChange={(e) => setContactPerson(e.target.value)}
                className="w-full h-11 px-3.5 bg-[#06080c] border border-[#1e2533] focus:border-[#e60000] rounded-lg text-sm text-white outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#8b95a5] uppercase tracking-wider mb-1.5">
                Phone Number *
              </label>
              <input
                type="tel"
                placeholder="+91 98765 43210"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full h-11 px-3.5 bg-[#06080c] border border-[#1e2533] focus:border-[#e60000] rounded-lg text-sm text-white outline-none"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#8b95a5] uppercase tracking-wider mb-1.5">
              Reason / Medical Context (Optional)
            </label>
            <textarea
              rows={2}
              placeholder="e.g. Scheduled for emergency bypass surgery tomorrow morning"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="w-full p-3 bg-[#06080c] border border-[#1e2533] focus:border-[#e60000] rounded-lg text-sm text-white outline-none resize-none"
            />
          </div>

          {/* Action buttons */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#1e2533]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-lg border border-gray-700 text-sm font-semibold text-gray-300 hover:text-white hover:border-gray-500 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-lg bg-[#e60000] hover:bg-[#b30000] text-sm font-bold text-white shadow-lg shadow-red-900/40 hover:shadow-red-800/60 transition-all flex items-center gap-2"
            >
              <i className="fa-solid fa-paper-plane"></i>
              Broadcast Blood Request
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};
