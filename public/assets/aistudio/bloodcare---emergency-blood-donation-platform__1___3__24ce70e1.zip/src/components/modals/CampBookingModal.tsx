import React, { useState } from 'react';
import { motion } from 'motion/react';
import { DonationCamp } from '../../types';

interface CampBookingModalProps {
  camp: DonationCamp | null;
  onClose: () => void;
  onConfirmBooking: (campId: string, slotTime: string, donorName: string) => void;
}

export const CampBookingModal: React.FC<CampBookingModalProps> = ({
  camp,
  onClose,
  onConfirmBooking,
}) => {
  const [donorName, setDonorName] = useState('');
  const [phone, setPhone] = useState('');
  const [bloodGroup, setBloodGroup] = useState('O+');
  const [selectedSlot, setSelectedSlot] = useState('10:00 AM - 11:00 AM');
  const [isSuccess, setIsSuccess] = useState(false);
  const [passCode, setPassCode] = useState('');

  if (!camp) return null;

  const slots = [
    '09:30 AM - 10:30 AM',
    '10:30 AM - 11:30 AM',
    '11:30 AM - 12:30 PM',
    '01:30 PM - 02:30 PM',
    '02:30 PM - 03:30 PM',
  ];

  const handleBook = (e: React.FormEvent) => {
    e.preventDefault();
    if (!donorName.trim() || !phone.trim()) return;

    const code = 'CAMP-' + Math.floor(100000 + Math.random() * 900000);
    setPassCode(code);
    setIsSuccess(true);
    onConfirmBooking(camp.id, selectedSlot, donorName);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <motion.div
        initial={{ opacity: 0, scale: 0.94, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95 }}
        transition={{ type: 'spring', damping: 25, stiffness: 350 }}
        className="relative w-full max-w-lg glass-panel border border-white/10 hover:border-red-500/50 rounded-3xl shadow-2xl p-6 text-white transition-all"
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#1e2533] pb-4 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#e60000]/20 flex items-center justify-center text-[#e60000] text-xl">
              <i className="fa-solid fa-tent"></i>
            </div>
            <div>
              <h2 className="text-xl font-bold tracking-tight">Reserve Camp Donation Slot</h2>
              <p className="text-xs text-[#8b95a5]">Free health screening & official certificate included</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white p-1 rounded-lg hover:bg-white/10"
          >
            <i className="fa-solid fa-xmark text-lg"></i>
          </button>
        </div>

        {isSuccess ? (
          /* Confirmation Pass */
          <div className="text-center py-4 space-y-4 animate-card-appear">
            <div className="w-16 h-16 mx-auto rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-3xl">
              <i className="fa-solid fa-check"></i>
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Donation Slot Confirmed!</h3>
              <p className="text-xs text-[#8b95a5]">
                Thank you, <strong className="text-white">{donorName}</strong>. You are booked for:
              </p>
            </div>

            <div className="bg-[#0b0e14] border border-[#1e2533] rounded-xl p-4 text-left text-xs space-y-2">
              <div className="flex justify-between">
                <span className="text-[#8b95a5]">Camp Venue:</span>
                <span className="font-semibold text-white">{camp.title}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#8b95a5]">Address:</span>
                <span className="font-semibold text-gray-300">{camp.address}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#8b95a5]">Date & Time Slot:</span>
                <span className="font-bold text-[#e60000]">
                  {camp.date} @ {selectedSlot}
                </span>
              </div>
              <div className="flex justify-between items-center pt-2 border-t border-[#1e2533]">
                <span className="text-[#8b95a5]">Digital Entry Pass:</span>
                <span className="font-mono text-sm font-bold text-emerald-400 px-2 py-0.5 bg-emerald-950/60 rounded border border-emerald-800">
                  {passCode}
                </span>
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-full py-2.5 rounded-xl bg-[#e60000] hover:bg-[#b30000] text-sm font-bold text-white transition-all shadow-lg"
            >
              Done
            </button>
          </div>
        ) : (
          /* Booking Form */
          <form onSubmit={handleBook} className="space-y-4">
            {/* Camp summary */}
            <div className="bg-[#181d29] p-3.5 rounded-xl border border-[#1e2533] text-xs">
              <div className="flex items-center justify-between mb-1">
                <h4 className="font-bold text-white text-sm">{camp.title}</h4>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#e60000]/20 text-red-300">
                  {camp.daysLeft} Days Left
                </span>
              </div>
              <p className="text-[#8b95a5] mb-2">📍 {camp.address}</p>
              <div className="flex items-center gap-2 text-[11px] text-gray-300">
                <i className="fa-solid fa-calendar-days text-[#e60000]"></i> {camp.date} ({camp.time})
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-[#8b95a5] uppercase mb-1">
                  Your Full Name *
                </label>
                <input
                  type="text"
                  placeholder="e.g. Gurpreet Singh"
                  value={donorName}
                  onChange={(e) => setDonorName(e.target.value)}
                  className="w-full h-10 px-3 bg-[#06080c] border border-[#1e2533] focus:border-[#e60000] rounded-lg text-xs text-white outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#8b95a5] uppercase mb-1">
                  Phone Number *
                </label>
                <input
                  type="tel"
                  placeholder="+91 98765 43210"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full h-10 px-3 bg-[#06080c] border border-[#1e2533] focus:border-[#e60000] rounded-lg text-xs text-white outline-none"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#8b95a5] uppercase mb-1">
                Select Your Blood Group
              </label>
              <select
                value={bloodGroup}
                onChange={(e) => setBloodGroup(e.target.value)}
                className="w-full h-10 px-3 bg-[#06080c] border border-[#1e2533] focus:border-[#e60000] rounded-lg text-xs text-white outline-none cursor-pointer"
              >
                <option value="A+">A+</option>
                <option value="A-">A-</option>
                <option value="B+">B+</option>
                <option value="B-">B-</option>
                <option value="O+">O+</option>
                <option value="O-">O-</option>
                <option value="AB+">AB+</option>
                <option value="AB-">AB-</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#8b95a5] uppercase mb-1.5">
                Choose Time Slot
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {slots.map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setSelectedSlot(s)}
                    className={`py-2 px-2 text-[11px] rounded-lg border font-semibold transition-all ${
                      selectedSlot === s
                        ? 'bg-[#e60000] text-white border-[#e60000] shadow-md shadow-red-950'
                        : 'bg-[#06080c] text-gray-400 border-[#1e2533] hover:text-white'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#1e2533]">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-lg border border-gray-700 text-xs font-semibold text-gray-300 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 rounded-lg bg-[#e60000] hover:bg-[#b30000] text-xs font-bold text-white shadow-lg shadow-red-900/40 transition-all flex items-center gap-1.5"
              >
                <i className="fa-solid fa-calendar-check"></i>
                Confirm Booking
              </button>
            </div>
          </form>
        )}
      </motion.div>
    </div>
  );
};
