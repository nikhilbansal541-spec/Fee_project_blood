import React, { useState } from 'react';
import { motion } from 'motion/react';
import { User, BloodGroup } from '../../types';

interface LoginSignupModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (user: User) => void;
  initialMode?: 'login' | 'signup';
}

export const LoginSignupModal: React.FC<LoginSignupModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
  initialMode = 'login',
}) => {
  const [isLoginTab, setIsLoginTab] = useState(initialMode === 'login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [name, setName] = useState('');
  const [bloodGroup, setBloodGroup] = useState<BloodGroup>('O+');
  const [role, setRole] = useState<'donor' | 'requester'>('donor');
  const [remember, setRemember] = useState(true);
  const [message, setMessage] = useState<{ text: string; isError: boolean } | null>(null);
  const [isForgotOpen, setIsForgotOpen] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');

  if (!isOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) {
      setMessage({ text: 'Please enter both email and password.', isError: true });
      return;
    }

    const loggedUser: User = {
      id: 'USR-' + Math.floor(1000 + Math.random() * 9000),
      name: email.split('@')[0],
      email: email.trim(),
      role: 'donor',
      bloodGroup: 'O+',
      city: 'Chandigarh',
    };

    if (remember) {
      localStorage.setItem('bloodcare_user', JSON.stringify(loggedUser));
    }

    setMessage({ text: `Welcome back, ${loggedUser.name}!`, isError: false });
    setTimeout(() => {
      onLoginSuccess(loggedUser);
      onClose();
    }, 800);
  };

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !password.trim()) {
      setMessage({ text: 'Please fill in all required fields.', isError: true });
      return;
    }

    const newUser: User = {
      id: 'USR-' + Math.floor(1000 + Math.random() * 9000),
      name: name.trim(),
      email: email.trim(),
      role,
      bloodGroup: role === 'donor' ? bloodGroup : undefined,
      city: 'Chandigarh',
    };

    if (remember) {
      localStorage.setItem('bloodcare_user', JSON.stringify(newUser));
    }

    setMessage({ text: `Account created successfully for ${newUser.name}!`, isError: false });
    setTimeout(() => {
      onLoginSuccess(newUser);
      onClose();
    }, 800);
  };

  const handleDemoLogin = (type: 'donor' | 'requester') => {
    const demoUser: User =
      type === 'donor'
        ? {
            id: 'DON-1',
            name: 'Rahul Sharma',
            email: 'rahul.sharma@example.com',
            role: 'donor',
            bloodGroup: 'O+',
            city: 'Chandigarh',
            phone: '+91 98140 12345',
          }
        : {
            id: 'REQ-USR-1',
            name: 'Dr. Anita Roy',
            email: 'anita.pgi@hospital.org',
            role: 'requester',
            city: 'Chandigarh',
            phone: '+91 98140 77665',
          };

    if (remember) {
      localStorage.setItem('bloodcare_user', JSON.stringify(demoUser));
    }
    setMessage({ text: `Logged in as ${demoUser.name} (${demoUser.role.toUpperCase()})`, isError: false });
    setTimeout(() => {
      onLoginSuccess(demoUser);
      onClose();
    }, 600);
  };

  const handleForgotPasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotEmail.trim()) return;
    setMessage({
      text: `Password reset instructions sent to ${forgotEmail}. Please check your inbox.`,
      isError: false,
    });
    setIsForgotOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <motion.div
        initial={{ opacity: 0, scale: 0.94, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95 }}
        transition={{ type: 'spring', damping: 25, stiffness: 350 }}
        className="relative w-full max-w-md glass-panel border border-white/10 hover:border-red-500/50 rounded-3xl shadow-2xl p-6 text-white transition-all"
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#1e2533] pb-4 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-[#e60000]/20 flex items-center justify-center text-[#e60000] text-lg">
              <i className="fa-solid fa-droplet"></i>
            </div>
            <div>
              <h3 className="text-lg font-bold">BloodCare Account</h3>
              <p className="text-[11px] text-[#8b95a5]">Secure donor and requester portal</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white p-1 rounded-lg hover:bg-white/10"
          >
            <i className="fa-solid fa-xmark text-lg"></i>
          </button>
        </div>

        {/* Tab switch */}
        {!isForgotOpen && (
          <div className="flex bg-[#0b0e14] p-1 rounded-xl border border-[#1e2533] mb-5">
            <button
              onClick={() => {
                setIsLoginTab(true);
                setMessage(null);
              }}
              className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
                isLoginTab
                  ? 'bg-[#e60000] text-white shadow-md shadow-red-950'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              Sign In
            </button>
            <button
              onClick={() => {
                setIsLoginTab(false);
                setMessage(null);
              }}
              className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
                !isLoginTab
                  ? 'bg-[#e60000] text-white shadow-md shadow-red-950'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              Create Account
            </button>
          </div>
        )}

        {message && (
          <div
            className={`p-3 rounded-lg text-xs mb-4 border ${
              message.isError
                ? 'bg-red-950/60 border-red-800 text-red-200'
                : 'bg-emerald-950/60 border-emerald-800 text-emerald-200'
            }`}
          >
            {message.text}
          </div>
        )}

        {isForgotOpen ? (
          /* Forgot Password subform */
          <form onSubmit={handleForgotPasswordSubmit} className="space-y-4">
            <h4 className="text-sm font-bold text-white">Reset Your Password</h4>
            <p className="text-xs text-[#8b95a5]">
              Enter your registered email address and we will dispatch a password recovery link.
            </p>
            <input
              type="email"
              placeholder="Enter your email"
              value={forgotEmail}
              onChange={(e) => setForgotEmail(e.target.value)}
              className="w-full h-11 px-3 bg-[#06080c] border border-[#1e2533] focus:border-[#e60000] rounded-lg text-xs text-white outline-none"
              required
            />
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setIsForgotOpen(false)}
                className="flex-1 py-2.5 rounded-lg border border-gray-700 text-xs font-semibold text-gray-300 hover:text-white"
              >
                Back to Login
              </button>
              <button
                type="submit"
                className="flex-1 py-2.5 rounded-lg bg-[#e60000] hover:bg-[#b30000] text-xs font-bold text-white shadow-lg"
              >
                Send Reset Link
              </button>
            </div>
          </form>
        ) : isLoginTab ? (
          /* Sign In Form */
          <form onSubmit={handleLogin} className="space-y-3.5">
            <div>
              <label className="block text-xs font-semibold text-[#8b95a5] mb-1">Email Address</label>
              <div className="relative">
                <i className="fa-solid fa-envelope absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500 text-xs"></i>
                <input
                  type="email"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full h-11 pl-9 pr-3 bg-[#06080c] border border-[#1e2533] focus:border-[#e60000] rounded-lg text-xs text-white outline-none"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#8b95a5] mb-1">Password</label>
              <div className="relative">
                <i className="fa-solid fa-lock absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500 text-xs"></i>
                <input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full h-11 pl-9 pr-10 bg-[#06080c] border border-[#1e2533] focus:border-[#e60000] rounded-lg text-xs text-white outline-none"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300 text-xs"
                >
                  <i className={`fa-solid ${showPassword ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between text-xs text-[#8b95a5] pt-1">
              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={remember}
                  onChange={(e) => setRemember(e.target.checked)}
                  className="w-3.5 h-3.5 accent-[#e60000] rounded"
                />
                Remember me
              </label>
              <button
                type="button"
                onClick={() => setIsForgotOpen(true)}
                className="text-[#ff5252] hover:underline"
              >
                Forgot Password?
              </button>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-lg bg-[#e60000] hover:bg-[#b30000] text-xs font-bold text-white shadow-lg shadow-red-950 transition-all flex items-center justify-center gap-2"
            >
              <i className="fa-solid fa-right-to-bracket"></i>
              Login to Account
            </button>

            {/* Quick Demo Logins */}
            <div className="pt-2 border-t border-[#1e2533]">
              <p className="text-[11px] text-center text-gray-500 mb-2">Or instant 1-click test login:</p>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => handleDemoLogin('donor')}
                  className="p-2 bg-[#181d29] hover:bg-[#202737] border border-[#1e2533] rounded-lg text-[11px] font-semibold text-gray-300 hover:text-white transition-colors"
                >
                  🩸 Demo Donor
                </button>
                <button
                  type="button"
                  onClick={() => handleDemoLogin('requester')}
                  className="p-2 bg-[#181d29] hover:bg-[#202737] border border-[#1e2533] rounded-lg text-[11px] font-semibold text-gray-300 hover:text-white transition-colors"
                >
                  🏥 Demo Hospital
                </button>
              </div>
            </div>
          </form>
        ) : (
          /* Sign Up Form */
          <form onSubmit={handleSignup} className="space-y-3.5">
            <div>
              <label className="block text-xs font-semibold text-[#8b95a5] mb-1">Your Full Name</label>
              <input
                type="text"
                placeholder="e.g. Jaswinder Kaur"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full h-11 px-3 bg-[#06080c] border border-[#1e2533] focus:border-[#e60000] rounded-lg text-xs text-white outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#8b95a5] mb-1">Email Address</label>
              <input
                type="email"
                placeholder="Enter email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full h-11 px-3 bg-[#06080c] border border-[#1e2533] focus:border-[#e60000] rounded-lg text-xs text-white outline-none"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-[#8b95a5] mb-1">Account Role</label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value as 'donor' | 'requester')}
                  className="w-full h-11 px-2.5 bg-[#06080c] border border-[#1e2533] focus:border-[#e60000] rounded-lg text-xs text-white outline-none"
                >
                  <option value="donor">Blood Donor</option>
                  <option value="requester">Patient / Hospital</option>
                </select>
              </div>

              {role === 'donor' ? (
                <div>
                  <label className="block text-xs font-semibold text-[#8b95a5] mb-1">Blood Group</label>
                  <select
                    value={bloodGroup}
                    onChange={(e) => setBloodGroup(e.target.value as BloodGroup)}
                    className="w-full h-11 px-2.5 bg-[#06080c] border border-[#1e2533] focus:border-[#e60000] rounded-lg text-xs text-white outline-none"
                  >
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                  </select>
                </div>
              ) : (
                <div>
                  <label className="block text-xs font-semibold text-[#8b95a5] mb-1">Hospital / City</label>
                  <input
                    type="text"
                    defaultValue="Chandigarh"
                    className="w-full h-11 px-2.5 bg-[#06080c] border border-[#1e2533] focus:border-[#e60000] rounded-lg text-xs text-white outline-none"
                  />
                </div>
              )}
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#8b95a5] mb-1">Set Password</label>
              <input
                type="password"
                placeholder="Choose a secure password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full h-11 px-3 bg-[#06080c] border border-[#1e2533] focus:border-[#e60000] rounded-lg text-xs text-white outline-none"
                required
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-lg bg-[#e60000] hover:bg-[#b30000] text-xs font-bold text-white shadow-lg shadow-red-950 transition-all flex items-center justify-center gap-2"
            >
              <i className="fa-solid fa-user-check"></i>
              Create BloodCare Account
            </button>
          </form>
        )}
      </motion.div>
    </div>
  );
};
