import React, { useState } from 'react';
import { motion } from 'motion/react';
import { BloodRequest } from '../../types';

interface TrackRequestModalProps {
  isOpen: boolean;
  onClose: () => void;
  requests: BloodRequest[];
  onOpenNewRequest: () => void;
}

export const TrackRequestModal: React.FC<TrackRequestModalProps> = ({
  isOpen,
  onClose,
  requests,
  onOpenNewRequest,
}) => {
  const [searchId, setSearchId] = useState('');
  const [selectedReq, setSelectedReq] = useState<BloodRequest | null>(
    requests.length > 0 ? requests[0] : null
  );

  if (!isOpen) return null;

  const filteredRequests = requests.filter(
    (r) =>
      r.id.toLowerCase().includes(searchId.toLowerCase()) ||
      r.patientName.toLowerCase().includes(searchId.toLowerCase()) ||
      r.hospital.toLowerCase().includes(searchId.toLowerCase()) ||
      r.bloodGroup.toLowerCase().includes(searchId.toLowerCase())
  );

  const getStatusBadge = (status: BloodRequest['status']) => {
    switch (status) {
      case 'submitted':
        return (
          <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-amber-950 text-amber-400 border border-amber-800 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse"></span>
            Submitted / Verifying
          </span>
        );
      case 'donors_notified':
        return (
          <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-blue-950 text-blue-400 border border-blue-800 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-ping"></span>
            Donors Notified
          </span>
        );
      case 'matched':
        return (
          <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800 flex items-center gap-1">
            <i className="fa-solid fa-check"></i>
            Donors Responded
          </span>
        );
      case 'completed':
        return (
          <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-purple-950 text-purple-400 border border-purple-800 flex items-center gap-1">
            <i className="fa-solid fa-circle-check"></i>
            Fulfilled
          </span>
        );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <motion.div
        initial={{ opacity: 0, scale: 0.94, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95 }}
        transition={{ type: 'spring', damping: 25, stiffness: 350 }}
        className="relative w-full max-w-2xl max-h-[92vh] overflow-y-auto glass-panel border border-white/10 hover:border-red-500/50 rounded-3xl shadow-2xl p-6 text-white transition-all"
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#1e2533] pb-4 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#e60000]/20 flex items-center justify-center text-[#e60000] text-xl">
              <i className="fa-solid fa-route"></i>
            </div>
            <div>
              <h2 className="text-xl font-bold tracking-tight">Live Blood Request Tracker</h2>
              <p className="text-xs text-[#8b95a5]">Monitor real-time responses from donors and hospitals</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white p-1 rounded-lg hover:bg-white/10"
          >
            <i className="fa-solid fa-xmark text-lg"></i>
          </button>
        </div>

        {/* Search input */}
        <div className="flex gap-2 mb-4">
          <div className="relative flex-1">
            <i className="fa-solid fa-magnifying-glass absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 text-xs"></i>
            <input
              type="text"
              placeholder="Search by Request ID (e.g. REQ-4091) or Patient Name..."
              value={searchId}
              onChange={(e) => setSearchId(e.target.value)}
              className="w-full h-10 pl-9 pr-3 bg-[#06080c] border border-[#1e2533] focus:border-[#e60000] rounded-lg text-xs text-white outline-none"
            />
          </div>
          <button
            onClick={onOpenNewRequest}
            className="px-3.5 h-10 bg-[#e60000] hover:bg-[#b30000] rounded-lg text-xs font-bold text-white flex items-center gap-1.5 transition-colors shrink-0"
          >
            <i className="fa-solid fa-plus"></i> New Request
          </button>
        </div>

        {/* Two-column layout: Request List & Detailed Tracking */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
          {/* List of requests */}
          <div className="md:col-span-5 space-y-2 max-h-[360px] overflow-y-auto pr-1">
            {filteredRequests.map((req) => (
              <div
                key={req.id}
                onClick={() => setSelectedReq(req)}
                className={`p-3 rounded-xl border cursor-pointer transition-all ${
                  selectedReq?.id === req.id
                    ? 'bg-[#181d29] border-[#e60000] shadow-md shadow-red-950/30'
                    : 'bg-[#0b0e14] border-[#1e2533] hover:border-gray-700'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-mono text-xs font-bold text-[#e60000]">{req.id}</span>
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-[#e60000]/20 text-red-300">
                    {req.bloodGroup} • {req.units} Units
                  </span>
                </div>
                <h4 className="text-sm font-semibold truncate text-white">{req.patientName}</h4>
                <p className="text-[11px] text-[#8b95a5] truncate">📍 {req.hospital}</p>
                <div className="mt-2 flex items-center justify-between">
                  {getStatusBadge(req.status)}
                  <span className="text-[10px] text-gray-500">{req.timestamp}</span>
                </div>
              </div>
            ))}
            {filteredRequests.length === 0 && (
              <div className="p-6 text-center text-xs text-[#8b95a5] bg-[#0b0e14] rounded-xl border border-[#1e2533]">
                No matching requests found.
              </div>
            )}
          </div>

          {/* Details & Live Stepper */}
          <div className="md:col-span-7 bg-[#0b0e14] p-4 rounded-xl border border-[#1e2533]">
            {selectedReq ? (
              <div className="space-y-4">
                <div className="flex items-start justify-between border-b border-[#1e2533] pb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-sm font-bold text-[#e60000]">{selectedReq.id}</span>
                      <span className="px-2 py-0.5 rounded text-xs font-black bg-red-600 text-white">
                        {selectedReq.bloodGroup}
                      </span>
                    </div>
                    <h3 className="text-base font-bold text-white mt-1">{selectedReq.patientName}</h3>
                    <p className="text-xs text-[#8b95a5]">
                      {selectedReq.hospital}, {selectedReq.city}
                    </p>
                  </div>
                  {getStatusBadge(selectedReq.status)}
                </div>

                {/* Urgency & Reason */}
                <div className="bg-[#12161f] p-3 rounded-lg border border-[#1e2533] text-xs space-y-1">
                  <div className="flex justify-between">
                    <span className="text-[#8b95a5]">Units Needed:</span>
                    <span className="font-bold text-white">{selectedReq.units} Units (WB / PRBC)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#8b95a5]">Contact Person:</span>
                    <span className="font-semibold text-white">{selectedReq.contactPerson}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#8b95a5]">Contact Phone:</span>
                    <a href={`tel:${selectedReq.phone}`} className="text-[#ff5252] hover:underline font-mono">
                      {selectedReq.phone}
                    </a>
                  </div>
                  {selectedReq.reason && (
                    <div className="pt-1 text-[#8b95a5]">
                      <span className="text-gray-400 font-medium">Context:</span> {selectedReq.reason}
                    </div>
                  )}
                </div>

                {/* Tracking Progress Steps */}
                <div>
                  <h4 className="text-xs font-semibold text-[#8b95a5] uppercase tracking-wider mb-3">
                    Progress Timeline
                  </h4>
                  <div className="relative pl-6 space-y-4 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-[#1e2533]">
                    {/* Step 1 */}
                    <div className="relative">
                      <span className="absolute -left-6 top-0.5 w-4 h-4 rounded-full bg-emerald-500 flex items-center justify-center text-[10px] text-black font-bold">
                        ✓
                      </span>
                      <p className="text-xs font-bold text-white">Emergency Request Broadcast</p>
                      <p className="text-[11px] text-gray-400">Request logged in BloodCare network</p>
                    </div>

                    {/* Step 2 */}
                    <div className="relative">
                      <span
                        className={`absolute -left-6 top-0.5 w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-bold ${
                          selectedReq.status !== 'submitted'
                            ? 'bg-emerald-500 text-black'
                            : 'bg-amber-500 text-black animate-pulse'
                        }`}
                      >
                        {selectedReq.status !== 'submitted' ? '✓' : '2'}
                      </span>
                      <p className="text-xs font-bold text-white">
                        Donors Notified ({selectedReq.matchedDonorsCount} active matches)
                      </p>
                      <p className="text-[11px] text-gray-400">SMS & push alerts dispatched in radius</p>
                    </div>

                    {/* Step 3 */}
                    <div className="relative">
                      <span
                        className={`absolute -left-6 top-0.5 w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-bold ${
                          selectedReq.status === 'matched' || selectedReq.status === 'completed'
                            ? 'bg-emerald-500 text-black'
                            : 'bg-gray-700 text-gray-300'
                        }`}
                      >
                        {selectedReq.status === 'matched' || selectedReq.status === 'completed' ? '✓' : '3'}
                      </span>
                      <p className="text-xs font-bold text-white">Donor Responded / Confirmed</p>
                      <p className="text-[11px] text-gray-400">
                        {selectedReq.status === 'matched' || selectedReq.status === 'completed'
                          ? 'Donors accepted and en route to hospital'
                          : 'Awaiting donor confirmation'}
                      </p>
                    </div>

                    {/* Step 4 */}
                    <div className="relative">
                      <span
                        className={`absolute -left-6 top-0.5 w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-bold ${
                          selectedReq.status === 'completed'
                            ? 'bg-emerald-500 text-black'
                            : 'bg-gray-700 text-gray-300'
                        }`}
                      >
                        {selectedReq.status === 'completed' ? '✓' : '4'}
                      </span>
                      <p className="text-xs font-bold text-white">Blood Unit Transfused / Handed Over</p>
                    </div>
                  </div>
                </div>

                {/* Call Contact Button */}
                <div className="pt-2">
                  <a
                    href={`tel:${selectedReq.phone}`}
                    className="w-full py-2.5 rounded-lg bg-[#181d29] hover:bg-[#202737] border border-[#1e2533] hover:border-emerald-500 text-xs font-bold text-emerald-400 flex items-center justify-center gap-2 transition-all"
                  >
                    <i className="fa-solid fa-phone"></i>
                    Call Hospital Contact ({selectedReq.contactPerson})
                  </a>
                </div>
              </div>
            ) : (
              <div className="h-full flex items-center justify-center text-center p-8 text-xs text-[#8b95a5]">
                Select a request on the left to inspect its live status.
              </div>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
};
