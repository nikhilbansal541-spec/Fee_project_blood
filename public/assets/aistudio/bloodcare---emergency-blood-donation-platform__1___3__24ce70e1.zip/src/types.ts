export type BloodGroup = 'A+' | 'A-' | 'B+' | 'B-' | 'O+' | 'O-' | 'AB+' | 'AB-';

export interface Donor {
  id: string;
  name: string;
  bloodGroup: BloodGroup;
  city: string;
  phone: string;
  email: string;
  available: boolean;
  lastDonationDate: string;
  verified: boolean;
  donationsCount: number;
}

export interface BloodRequest {
  id: string;
  patientName: string;
  bloodGroup: BloodGroup;
  units: number;
  hospital: string;
  city: string;
  urgency: 'critical' | 'urgent' | 'standard';
  contactPerson: string;
  phone: string;
  reason: string;
  status: 'submitted' | 'donors_notified' | 'matched' | 'completed';
  timestamp: string;
  matchedDonorsCount: number;
}

export interface DonationCamp {
  id: string;
  title: string;
  city: string;
  address: string;
  date: string;
  time: string;
  daysLeft: number;
  totalSlots: number;
  bookedSlots: number;
  organizer: string;
  benefits: string[];
  pinPosition: { top: string; left: string };
  badgeText: string;
}

export interface SupportTicket {
  id: string;
  name: string;
  email: string;
  message: string;
  timestamp: string;
  status: 'Open' | 'In Progress' | 'Resolved';
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'donor' | 'requester';
  bloodGroup?: BloodGroup;
  city?: string;
  phone?: string;
}
