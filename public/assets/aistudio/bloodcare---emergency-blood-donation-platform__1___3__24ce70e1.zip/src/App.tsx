import React, { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Donor, BloodRequest, DonationCamp, User } from './types';
import { INITIAL_DONORS, INITIAL_REQUESTS, INITIAL_CAMPS } from './data/initialData';
import { ParticlesBackground } from './components/ParticlesBackground';
import { CursorGlow } from './components/CursorGlow';
import { HeartbeatECGBanner } from './components/HeartbeatECGBanner';
import { Navbar } from './components/Navbar';
import { LiveTicker } from './components/LiveTicker';
import { HomeDashboard } from './components/views/HomeDashboard';
import { DonorsView } from './components/views/DonorsView';
import { ServicesView } from './components/views/ServicesView';
import { AboutView } from './components/views/AboutView';
import { ContactView } from './components/views/ContactView';
import { CampsView } from './components/views/CampsView';
import { sfx } from './utils/audio';

import { RequestBloodModal } from './components/modals/RequestBloodModal';
import { ContactDonorModal } from './components/modals/ContactDonorModal';
import { RegisterDonorModal } from './components/modals/RegisterDonorModal';
import { TrackRequestModal } from './components/modals/TrackRequestModal';
import { CampBookingModal } from './components/modals/CampBookingModal';
import { EmergencySOSModal } from './components/modals/EmergencySOSModal';
import { LoginSignupModal } from './components/modals/LoginSignupModal';

export default function App() {
  const [currentView, setCurrentView] = useState<string>('home');
  const [donors, setDonors] = useState<Donor[]>(() => {
    const saved = localStorage.getItem('bloodcare_donors');
    return saved ? JSON.parse(saved) : INITIAL_DONORS;
  });

  const [requests, setRequests] = useState<BloodRequest[]>(() => {
    const saved = localStorage.getItem('bloodcare_requests');
    return saved ? JSON.parse(saved) : INITIAL_REQUESTS;
  });

  const [camps, setCamps] = useState<DonationCamp[]>(() => {
    const saved = localStorage.getItem('bloodcare_camps');
    return saved ? JSON.parse(saved) : INITIAL_CAMPS;
  });

  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('bloodcare_user');
    return saved ? JSON.parse(saved) : null;
  });

  // Modals state
  const [isRequestBloodOpen, setIsRequestBloodOpen] = useState(false);
  const [isTrackRequestOpen, setIsTrackRequestOpen] = useState(false);
  const [isRegisterDonorOpen, setIsRegisterDonorOpen] = useState(false);
  const [isEmergencySOSOpen, setIsEmergencySOSOpen] = useState(false);
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [contactDonorTarget, setContactDonorTarget] = useState<Donor | null>(null);
  const [bookingCampTarget, setBookingCampTarget] = useState<DonationCamp | null>(null);

  // Toast notifications
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'info' | 'alert' } | null>(null);

  const showToast = (message: string, type: 'success' | 'info' | 'alert' = 'success') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(null);
    }, 4500);
  };

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('bloodcare_donors', JSON.stringify(donors));
  }, [donors]);

  useEffect(() => {
    localStorage.setItem('bloodcare_requests', JSON.stringify(requests));
  }, [requests]);

  useEffect(() => {
    localStorage.setItem('bloodcare_camps', JSON.stringify(camps));
  }, [camps]);

  // Handlers
  const handleCreateRequest = (
    data: Omit<BloodRequest, 'id' | 'timestamp' | 'status' | 'matchedDonorsCount'>
  ) => {
    const matchingCount = donors.filter(
      (d) => d.bloodGroup === data.bloodGroup && d.available
    ).length;

    const newRequest: BloodRequest = {
      ...data,
      id: 'REQ-' + Math.floor(1000 + Math.random() * 9000),
      timestamp: 'Just now',
      status: 'donors_notified',
      matchedDonorsCount: matchingCount,
    };

    setRequests([newRequest, ...requests]);
    sfx.playAlert();
    showToast(
      `🚨 Emergency Request #${newRequest.id} broadcast! ${matchingCount} verified donors alerted in ${newRequest.city}.`,
      'alert'
    );
  };

  const handleRegisterDonor = (
    data: Omit<Donor, 'id' | 'donationsCount' | 'verified'>
  ) => {
    const newDonor: Donor = {
      ...data,
      id: 'DON-' + (donors.length + 1),
      donationsCount: 1,
      verified: true,
    };

    setDonors([newDonor, ...donors]);
    sfx.playSuccess();
    showToast(`🩸 Welcome ${newDonor.name}! You are registered as an active ${newDonor.bloodGroup} donor.`);
  };

  const handleConfirmCampBooking = (campId: string, slotTime: string, donorName: string) => {
    setCamps((prev) =>
      prev.map((c) =>
        c.id === campId ? { ...c, bookedSlots: Math.min(c.bookedSlots + 1, c.totalSlots) } : c
      )
    );
    sfx.playSuccess();
    showToast(`Appointment booked for ${donorName} on ${slotTime}! Entry pass generated.`);
  };

  const handleLogout = () => {
    localStorage.removeItem('bloodcare_user');
    setUser(null);
    sfx.playClick();
    showToast('You have been signed out.', 'info');
  };

  return (
    <div className="relative min-h-screen bg-[#06080c] text-white flex flex-col font-sans selection:bg-red-600 selection:text-white">
      {/* Dynamic Proximity Particle Constellation */}
      <ParticlesBackground />

      {/* Cybernetic Glowing Cursor Follower */}
      <CursorGlow />

      {/* Sticky Top Navbar */}
      <Navbar
        currentView={currentView}
        onNavigate={(view) => {
          setCurrentView(view);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onRequestBlood={() => {
          sfx.playAlert();
          setIsRequestBloodOpen(true);
        }}
        onEmergencySOS={() => {
          sfx.playAlert();
          setIsEmergencySOSOpen(true);
        }}
        onOpenLogin={() => {
          sfx.playClick();
          setIsLoginOpen(true);
        }}
        user={user}
        onLogout={handleLogout}
      />

      {/* Real-time Cardiac Rhythm ECG Banner */}
      <HeartbeatECGBanner />

      {/* Live Marquee Network Status Ticker */}
      <LiveTicker />

      {/* Main Content Area with Animated View Switching */}
      <main className="relative z-10 flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <AnimatePresence mode="wait">
          {currentView === 'home' && (
            <motion.div
              key="home"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.3 }}
            >
              <HomeDashboard
                onNavigate={(view) => {
                  sfx.playClick();
                  setCurrentView(view);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                onRequestBlood={() => {
                  sfx.playAlert();
                  setIsRequestBloodOpen(true);
                }}
                onTrackRequest={() => {
                  sfx.playClick();
                  setIsTrackRequestOpen(true);
                }}
                onRegisterDonor={() => {
                  sfx.playHeartbeat();
                  setIsRegisterDonorOpen(true);
                }}
                onSelectCamp={(camp) => {
                  sfx.playClick();
                  setBookingCampTarget(camp);
                }}
                camps={camps}
                donorsCount={donors.length}
              />
            </motion.div>
          )}

          {currentView === 'donors' && (
            <motion.div
              key="donors"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.3 }}
            >
              <DonorsView
                donors={donors}
                onContactDonor={(donor) => {
                  sfx.playClick();
                  setContactDonorTarget(donor);
                }}
                onRegisterDonor={() => {
                  sfx.playHeartbeat();
                  setIsRegisterDonorOpen(true);
                }}
              />
            </motion.div>
          )}

          {currentView === 'services' && (
            <motion.div
              key="services"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.3 }}
            >
              <ServicesView
                onNavigate={(view) => {
                  setCurrentView(view);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                onRequestBlood={() => setIsRequestBloodOpen(true)}
                onTrackRequest={() => setIsTrackRequestOpen(true)}
                onRegisterDonor={() => setIsRegisterDonorOpen(true)}
                onEmergencySOS={() => setIsEmergencySOSOpen(true)}
              />
            </motion.div>
          )}

          {currentView === 'about' && (
            <motion.div
              key="about"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.3 }}
            >
              <AboutView
                onRegisterDonor={() => setIsRegisterDonorOpen(true)}
                onNavigate={(view) => {
                  setCurrentView(view);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
              />
            </motion.div>
          )}

          {currentView === 'camps' && (
            <motion.div
              key="camps"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.3 }}
            >
              <CampsView
                camps={camps}
                onBookCamp={(camp) => setBookingCampTarget(camp)}
              />
            </motion.div>
          )}

          {currentView === 'contact' && (
            <motion.div
              key="contact"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.3 }}
            >
              <ContactView onEmergencySOS={() => setIsEmergencySOSOpen(true)} />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Global Animated Toast Notification */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: 25, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            className="fixed bottom-6 right-6 z-50"
          >
            <div
              className={`px-4 py-3 rounded-2xl shadow-2xl flex items-center gap-3 border text-xs sm:text-sm font-semibold backdrop-blur-xl ${
                toast.type === 'alert'
                  ? 'bg-red-950/95 text-red-100 border-red-600 shadow-red-950/70'
                  : toast.type === 'info'
                  ? 'bg-blue-950/95 text-blue-100 border-blue-600 shadow-blue-950/70'
                  : 'bg-emerald-950/95 text-emerald-100 border-emerald-600 shadow-emerald-950/70'
              }`}
            >
              <i
                className={`fa-solid ${
                  toast.type === 'alert'
                    ? 'fa-triangle-exclamation text-red-400 animate-pulse'
                    : toast.type === 'info'
                    ? 'fa-circle-info text-blue-400'
                    : 'fa-circle-check text-emerald-400'
                }`}
              ></i>
              <span>{toast.message}</span>
              <button
                onClick={() => setToast(null)}
                className="text-gray-400 hover:text-white ml-2 text-xs cursor-pointer"
              >
                <i className="fa-solid fa-xmark"></i>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Modals */}
      <RequestBloodModal
        isOpen={isRequestBloodOpen}
        onClose={() => setIsRequestBloodOpen(false)}
        onSubmit={handleCreateRequest}
        donors={donors}
      />

      <ContactDonorModal
        donor={contactDonorTarget}
        onClose={() => setContactDonorTarget(null)}
        onSendAlert={(donorName) => {
          showToast(`Emergency alert ping dispatched to ${donorName}'s phone!`, 'alert');
        }}
      />

      <RegisterDonorModal
        isOpen={isRegisterDonorOpen}
        onClose={() => setIsRegisterDonorOpen(false)}
        onRegister={handleRegisterDonor}
      />

      <TrackRequestModal
        isOpen={isTrackRequestOpen}
        onClose={() => setIsTrackRequestOpen(false)}
        requests={requests}
        onOpenNewRequest={() => {
          setIsTrackRequestOpen(false);
          setIsRequestBloodOpen(true);
        }}
      />

      <CampBookingModal
        camp={bookingCampTarget}
        onClose={() => setBookingCampTarget(null)}
        onConfirmBooking={handleConfirmCampBooking}
      />

      <EmergencySOSModal
        isOpen={isEmergencySOSOpen}
        onClose={() => setIsEmergencySOSOpen(false)}
        onRequestBlood={() => setIsRequestBloodOpen(true)}
      />

      <LoginSignupModal
        isOpen={isLoginOpen}
        onClose={() => setIsLoginOpen(false)}
        onLoginSuccess={(loggedUser) => {
          setUser(loggedUser);
          showToast(`Logged in successfully as ${loggedUser.name}!`);
        }}
      />

      {/* High-Level Footer */}
      <footer className="relative z-10 w-full border-t border-white/5 bg-[#05070a]/90 backdrop-blur-xl py-6 text-center text-xs text-[#8b95a5]">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <div className="w-6 h-6 rounded-lg bg-red-600/20 text-red-500 flex items-center justify-center text-xs">
              <i className="fa-solid fa-droplet"></i>
            </div>
            <span className="text-white font-bold tracking-tight">BloodCare Network</span>
            <span className="text-gray-500">• Powered by Verified Donors &amp; Hospitals</span>
          </div>
          <div className="flex items-center gap-4 text-[11px] flex-wrap justify-center">
            <button
              onClick={() => setIsEmergencySOSOpen(true)}
              className="text-red-400 hover:text-red-300 font-bold hover:underline cursor-pointer flex items-center gap-1.5"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping"></span>
              24/7 Hotline: +91 98765 43210
            </button>
            <span className="text-gray-700">•</span>
            <button
              onClick={() => setIsRequestBloodOpen(true)}
              className="hover:text-white cursor-pointer transition-colors"
            >
              Request Blood
            </button>
            <span className="text-gray-700">•</span>
            <button
              onClick={() => setIsRegisterDonorOpen(true)}
              className="hover:text-white cursor-pointer transition-colors"
            >
              Become a Donor
            </button>
            <span className="text-gray-700">•</span>
            <button
              onClick={() => setCurrentView('camps')}
              className="hover:text-white cursor-pointer transition-colors"
            >
              Donation Camps
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
